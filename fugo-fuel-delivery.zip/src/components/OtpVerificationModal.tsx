import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  KeyRound, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Fuel, 
  QrCode, 
  Banknote, 
  Smartphone, 
  Lock, 
  ShieldCheck,
  Check
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Order } from '../types';
import { fetchAppSettings, AppSettings, FugoCompleteOrderResult } from '../lib/supabase';

interface OtpVerificationModalProps {
  isOpen: boolean;
  order: Order | null;
  driverId?: string;
  hasReachedLocation?: boolean;
  onClose: () => void;
  onVerifyAndComplete: (otp: string, isCollected: boolean) => Promise<FugoCompleteOrderResult>;
  currencySymbol?: string;
}

export default function OtpVerificationModal({
  isOpen,
  order,
  driverId = 'HYD-NALLAGANDLA-01',
  hasReachedLocation = true,
  onClose,
  onVerifyAndComplete,
  currencySymbol = '₹'
}: OtpVerificationModalProps) {
  const [digits, setDigits] = useState<string[]>(['', '', '', '']);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<{
    attemptsLeft?: number;
    minutesLeft?: number;
    amountDue?: number;
    code?: string;
  }>({});

  // Payment states
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [confirmedPaymentType, setConfirmedPaymentType] = useState<'CASH' | 'UPI' | 'ONLINE' | null>(null);
  const [showUpiQr, setShowUpiQr] = useState(false);
  const [appSettings, setAppSettings] = useState<AppSettings>({
    merchant_name: 'Fugo',
    merchant_vpa: '',
    gstin: '',
    transport_fee: '0',
  });

  // Fetch Supabase app_settings on mount
  useEffect(() => {
    fetchAppSettings().then(settings => {
      setAppSettings(settings);
    });
  }, []);

  // Determine initial payment status when order changes
  useEffect(() => {
    if (order) {
      setDigits(['', '', '', '']);
      setErrorMessage(null);
      setErrorDetails({});
      setShowUpiQr(false);

      const isPaid = (order.payment_status || '').toUpperCase() === 'PAID';
      const amount = order.total_amount ?? order.price ?? 0;
      if (isPaid || amount <= 0) {
        setPaymentConfirmed(true);
        setConfirmedPaymentType('ONLINE');
      } else {
        setPaymentConfirmed(false);
        setConfirmedPaymentType(null);
      }
    }
  }, [order?.id, order?.payment_status, order?.total_amount]);

  if (!isOpen || !order) return null;

  const totalAmount = order.total_amount !== undefined && order.total_amount !== null
    ? order.total_amount
    : (order.price || 0);

  const paymentMethod = (order.payment_method || 'COD').toUpperCase();
  const isAlreadyPaid = (order.payment_status || '').toUpperCase() === 'PAID';

  // Construct UPI payment URI for QR code
  const merchantVpa = appSettings.merchant_vpa || 'fugo@icici';
  const merchantName = appSettings.merchant_name || 'Fugo Delivery';
  const upiPayUri = `upi://pay?pa=${encodeURIComponent(merchantVpa)}&pn=${encodeURIComponent(merchantName)}&am=${totalAmount}&cu=INR&tn=${encodeURIComponent(`Order ${order.id}`)}`;

  const handleDigitChange = (index: number, val: string) => {
    const clean = val.replace(/\D/g, '');
    const nextDigits = [...digits];
    nextDigits[index] = clean.slice(-1);
    setDigits(nextDigits);
    setErrorMessage(null);

    // Auto-focus next input
    if (clean && index < 3) {
      const nextInput = document.getElementById(`delivery-otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      const prevInput = document.getElementById(`delivery-otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleConfirmCash = () => {
    setPaymentConfirmed(true);
    setConfirmedPaymentType('CASH');
    setShowUpiQr(false);
    setErrorMessage(null);
  };

  const handleConfirmUpi = () => {
    setPaymentConfirmed(true);
    setConfirmedPaymentType('UPI');
    setShowUpiQr(false);
    setErrorMessage(null);
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    // Check payment confirmation first
    if (!isAlreadyPaid && totalAmount > 0 && !paymentConfirmed) {
      setErrorMessage('Please confirm cash or UPI received on delivery before finishing.');
      return;
    }

    const entered = digits.join('');
    if (entered.length < 4) {
      setErrorMessage('Please enter the full 4-digit customer delivery OTP.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await onVerifyAndComplete(entered, paymentConfirmed);
      if (!res.success) {
        setErrorMessage(res.error || 'Verification failed. Try again.');
        setErrorDetails({
          attemptsLeft: res.attempts_left,
          minutesLeft: res.minutes_left,
          amountDue: res.amount_due,
          code: res.code,
        });

        // If payment wasn't collected according to server, reset payment state
        if (res.code === 'PAYMENT_NOT_COLLECTED') {
          setPaymentConfirmed(false);
        }
      } else {
        onClose();
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Verification failed. Please retry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="w-full max-w-md bg-neutral-950 border-2 border-emerald-500/40 rounded-[36px] p-6 text-white shadow-2xl relative overflow-hidden my-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <KeyRound size={24} />
              </div>
              <div>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[9px] font-bold tracking-widest text-emerald-400 uppercase bg-emerald-500/15 px-2 py-0.5 rounded-md border border-emerald-500/30">
                    Location Reached
                  </span>
                  <span className="text-[9px] font-bold tracking-widest text-amber-400 uppercase bg-amber-500/15 px-2 py-0.5 rounded-md border border-amber-500/30">
                    Payment on Delivery
                  </span>
                </div>
                <h3 className="text-xl font-display font-black tracking-tight text-white uppercase italic">
                  Complete Delivery
                </h3>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          {/* Order Details summary */}
          <div className="my-4 p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Order ID:</span>
              <span className="font-mono font-bold text-amber-400">{order.id}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Service:</span>
              <span className="font-bold text-white flex items-center gap-1.5 truncate max-w-[220px]">
                <Fuel size={14} className="text-amber-400 shrink-0" />
                <span className="truncate">{order.fuelType || order.fuel_type || 'Fuel Delivery'}</span>
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Payment on Delivery:</span>
              <span className="font-extrabold text-emerald-400 text-sm font-display">
                {currencySymbol}{totalAmount.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Step 1: Payment on Delivery */}
          <div className="mb-5 p-4 rounded-2xl bg-neutral-900 border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Banknote size={13} className="text-amber-400" />
                <span>Step 1: Payment on Delivery</span>
                {paymentConfirmed && <CheckCircle2 size={12} className="text-emerald-400" />}
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-white/10 text-gray-300">
                Mode: {paymentMethod === 'COD' ? 'Cash on Delivery' : paymentMethod}
              </span>
            </div>

            {isAlreadyPaid ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                <span className="font-bold">Already paid online. Do not collect cash.</span>
              </div>
            ) : totalAmount <= 0 ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                <span className="font-bold">No payment required for this handover.</span>
              </div>
            ) : paymentConfirmed ? (
              <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                  <span className="font-bold">
                    Payment of {currencySymbol}{totalAmount} confirmed ({confirmedPaymentType || 'RECEIVED'})
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setPaymentConfirmed(false)}
                  className="text-[10px] text-gray-400 hover:text-white underline"
                >
                  Change
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-300">Collect from customer:</span>
                  <span className="text-base font-extrabold text-amber-300">
                    {currencySymbol}{totalAmount.toLocaleString()}
                  </span>
                </div>

                {/* UPI QR Display / Toggle */}
                <div className="bg-neutral-950/60 border border-white/10 rounded-xl p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <QrCode size={16} className="text-purple-400" />
                      <span className="text-xs text-gray-300 font-medium">Customer paying via UPI?</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowUpiQr(!showUpiQr)}
                      className="text-[11px] font-bold text-purple-400 hover:text-purple-300 underline"
                    >
                      {showUpiQr ? 'Hide QR' : 'Show UPI QR'}
                    </button>
                  </div>

                  {showUpiQr && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 p-4 bg-white rounded-2xl text-black text-center shadow-lg"
                    >
                      <p className="text-[10px] font-bold uppercase tracking-wider text-gray-500 mb-0.5">
                        {merchantName}
                      </p>
                      <p className="text-lg font-black text-black font-display mb-2.5">
                        {currencySymbol}{totalAmount.toLocaleString()}
                      </p>

                      <div className="bg-white p-2.5 rounded-xl border border-gray-200 inline-block shadow-inner">
                        <QRCodeSVG
                          value={upiPayUri}
                          size={150}
                          level="M"
                          includeMargin={false}
                        />
                      </div>

                      <div className="mt-2 text-[10px] text-gray-600 font-mono">
                        <span>UPI VPA: </span>
                        <strong className="text-gray-900">{merchantVpa}</strong>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Cash received and UPI received action buttons */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={handleConfirmCash}
                    className="py-3.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md"
                  >
                    <Banknote size={16} />
                    <span>Cash received</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleConfirmUpi}
                    className="py-3.5 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all active:scale-95 shadow-md"
                  >
                    <Smartphone size={16} />
                    <span>UPI received</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Step 2: Customer Handshake OTP */}
          <div className="mb-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block mb-1">
              Step 2: Customer Handover Code
            </span>
            <p className="text-xs text-gray-300 mb-4">
              Ask customer for their secret 4-digit delivery PIN to finish order in database.
            </p>
          </div>

          {/* 4 Digit OTP Inputs */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="flex justify-center gap-3">
              {digits.map((digit, idx) => (
                <input
                  key={idx}
                  id={`delivery-otp-${idx}`}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  disabled={!paymentConfirmed && !isAlreadyPaid && totalAmount > 0}
                  value={digit}
                  onChange={(e) => handleDigitChange(idx, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(idx, e)}
                  autoFocus={idx === 0 && (paymentConfirmed || isAlreadyPaid || totalAmount <= 0)}
                  className={`w-14 h-16 text-center text-2xl font-mono font-black rounded-2xl outline-none transition-all ${
                    !paymentConfirmed && !isAlreadyPaid && totalAmount > 0
                      ? 'bg-neutral-900/50 border-2 border-white/10 text-gray-500 cursor-not-allowed'
                      : 'bg-neutral-900 border-2 border-white/20 focus:border-emerald-400 text-white focus:ring-4 focus:ring-emerald-500/20'
                  }`}
                />
              ))}
            </div>

            {/* Error Message with tries left or lock timer */}
            {errorMessage && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-start gap-2.5 p-3.5 bg-red-950/70 border border-red-500/50 rounded-xl text-red-200 text-xs"
              >
                <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <span className="font-bold block leading-tight">{errorMessage}</span>
                  {errorDetails.code === 'LOCKED' && (
                    <span className="text-[10px] text-red-300 mt-1 block">
                      Security lockout active. Please wait {errorDetails.minutesLeft || 30} minutes before retrying.
                    </span>
                  )}
                </div>
              </motion.div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="flex-1 py-4 px-4 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-300 font-bold text-xs uppercase tracking-wider transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || (!paymentConfirmed && !isAlreadyPaid && totalAmount > 0)}
                className={`flex-2 py-4 px-6 rounded-2xl font-extrabold text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 ${
                  !paymentConfirmed && !isAlreadyPaid && totalAmount > 0
                    ? 'bg-neutral-800 text-gray-500 cursor-not-allowed border border-white/5'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-emerald-500/20'
                }`}
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>Verifying Code...</span>
                  </div>
                ) : (
                  <>
                    <CheckCircle2 size={16} />
                    <span>Complete Delivery</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
