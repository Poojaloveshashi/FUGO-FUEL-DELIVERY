import { createClient, SupabaseClient, RealtimeChannel } from '@supabase/supabase-js';
import { Order, OrderStatus } from '../types';
import { supabase as directSupabase, Supabase as directSupabaseNamespace, SUPABASE_PROJECT_ID, SUPABASE_URL, SUPABASE_ANON_KEY } from '../supabase';

import { FUEL_SALES_ENABLED } from '../config';

export { directSupabase as supabase, directSupabaseNamespace as Supabase };

// Credentials provided in user request (hardcoded fallback strings)
export const DEFAULT_SUPABASE_PROJECT_ID = 'arierwpjaksxxnmvbqwn';
export const DEFAULT_SUPABASE_URL = 'https://arierwpjaksxxnmvbqwn.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable__c-Q3k0ibuQMt3_mtYpRNw_Se-8kFbS';

export const HARDCODED_SUPABASE_URL = DEFAULT_SUPABASE_URL;
export const HARDCODED_SUPABASE_KEY = DEFAULT_SUPABASE_ANON_KEY;

export function isValidSupabaseUrl(url?: string): boolean {
  if (!url) return false;
  const clean = String(url).trim();
  if (!clean.startsWith('https://')) return false;
  if (clean.includes('your-project-id')) return false;
  if (clean === 'https://your-project-id.supabase.co' || clean === 'YOUR_SUPABASE_URL' || clean === 'MY_APP_URL') {
    return false;
  }
  return true;
}

export function isValidSupabaseKey(key?: string): boolean {
  if (!key) return false;
  const clean = String(key).trim();
  if (clean.toLowerCase() === 'ap-southeast-1') return false;
  if (clean === 'YOUR_ACTUAL_ANON_KEY' || clean === 'YOUR_SUPABASE_ANON_KEY') return false;
  return (
    clean.startsWith('sb_publishable_') ||
    clean.startsWith('sb_secret_') ||
    clean.startsWith('sb_') ||
    clean.startsWith('eyJ')
  );
}

const STORAGE_URL_KEY = 'fugo_supabase_url';
const STORAGE_KEY_KEY = 'fugo_supabase_anon_key';

export function getEffectiveSupabaseConfig(): {
  url: string;
  key: string;
  projectId: string;
  isFromEnv: boolean;
  source: 'env' | 'localStorage' | 'default';
} {
  const rawEnvUrl = (
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_URL) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.SUPABASE_URL) ||
    (typeof process !== 'undefined' && ((process as any).env?.VITE_SUPABASE_URL || (process as any).env?.SUPABASE_URL)) ||
    ''
  ).trim();

  const rawEnvKey = (
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_ANON_KEY) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_KEY) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.SUPABASE_ANON_KEY) ||
    (typeof import.meta !== 'undefined' && (import.meta as any).env?.SUPABASE_KEY) ||
    (typeof process !== 'undefined' && ((process as any).env?.VITE_SUPABASE_ANON_KEY || (process as any).env?.VITE_SUPABASE_KEY || (process as any).env?.SUPABASE_ANON_KEY || (process as any).env?.SUPABASE_KEY)) ||
    ''
  ).trim();

  const envUrl = isValidSupabaseUrl(rawEnvUrl) ? rawEnvUrl : '';
  const envKey = isValidSupabaseKey(rawEnvKey) ? rawEnvKey : '';

  let localUrl = '';
  let localKey = '';

  if (typeof localStorage !== 'undefined') {
    const rawLocalUrl = localStorage.getItem(STORAGE_URL_KEY)?.trim() || '';
    if (isValidSupabaseUrl(rawLocalUrl)) {
      localUrl = rawLocalUrl;
    } else if (rawLocalUrl) {
      localStorage.removeItem(STORAGE_URL_KEY);
    }

    const rawLocalKey = localStorage.getItem(STORAGE_KEY_KEY)?.trim() || '';
    if (rawLocalKey === 'sb_secret_1P7d_dTOUdmN68jBl27Ing_RCl-Q8PT') {
      localStorage.setItem(STORAGE_KEY_KEY, DEFAULT_SUPABASE_ANON_KEY);
      localKey = DEFAULT_SUPABASE_ANON_KEY;
    } else if (isValidSupabaseKey(rawLocalKey)) {
      localKey = rawLocalKey;
    } else if (rawLocalKey) {
      localStorage.removeItem(STORAGE_KEY_KEY);
    }
  }

  let url = localUrl || envUrl || DEFAULT_SUPABASE_URL;
  let key = localKey || envKey || DEFAULT_SUPABASE_ANON_KEY;
  let source: 'env' | 'localStorage' | 'default' = 'default';

  if (localUrl || localKey) {
    source = 'localStorage';
  } else if (envUrl || envKey) {
    source = 'env';
  }

  let projectId = DEFAULT_SUPABASE_PROJECT_ID;
  try {
    const parsed = new URL(url);
    const hostParts = parsed.hostname.split('.');
    if (hostParts.length > 0 && hostParts[0]) {
      projectId = hostParts[0];
    }
  } catch {
    if (url.includes('.supabase.co')) {
      projectId = url.replace(/https?:\/\//, '').split('.')[0];
    }
  }

  return {
    url,
    key,
    projectId,
    isFromEnv: Boolean(envUrl || envKey),
    source,
  };
}

export function getSupabaseClient(): SupabaseClient {
  return directSupabase;
}

export function resetSupabaseClient(newUrl?: string, newKey?: string) {
  if (newUrl !== undefined) {
    if (newUrl) localStorage.setItem(STORAGE_URL_KEY, newUrl);
    else localStorage.removeItem(STORAGE_URL_KEY);
  }
  if (newKey !== undefined) {
    if (newKey) localStorage.setItem(STORAGE_KEY_KEY, newKey);
    else localStorage.removeItem(STORAGE_KEY_KEY);
  }
  return getSupabaseClient();
}

/**
 * Evaluates whether an order row is a delivery job:
 * - Ignore rows where service_type = 'MAINTENANCE' (repair jobs)
 * - All other rows (FUEL, PARTS, TRANSPORT) are delivery jobs.
 */
export function isDeliveryOrder(row: any): boolean {
  if (!row) return false;
  const rawType = (row.service_type ?? row.serviceType ?? '').toString().trim().toUpperCase();
  // Ignore rows where service_type = 'MAINTENANCE' (repair jobs)
  if (rawType === 'MAINTENANCE') {
    return false;
  }
  if (!FUEL_SALES_ENABLED) {
    // While false: nobody can order/sell fuel; incoming jobs feed, dispatch radar, ringtone, and job dialog ignore service_type === 'FUEL'.
    // Drivers see and accept ONLY service_type === 'TRANSPORT' (vehicle pickup and return).
    return rawType === 'TRANSPORT';
  }
  // All other rows (FUEL, PARTS, TRANSPORT) are delivery jobs.
  return true;
}

export const isEligibleServiceType = (row: any, _role?: string) => isDeliveryOrder(row);

/**
 * Normalizes a raw Supabase order row into the application Order model.
 * - Job title: FUEL = fuel_type with litres; PARTS = description;
 *   TRANSPORT with job_kind VEHICLE_PICKUP = "Vehicle pickup for repair", VEHICLE_RETURN = "Return repaired vehicle".
 * - Shows the row's address and uses its lat/lng as the destination. Never uses driver_lat/driver_lng as destination.
 */
export function normalizeSupabaseOrder(row: any): Order {
  // Use row's lat/lng as destination. Never use driver_lat/driver_lng as destination.
  const rowLat = row.lat ?? row.latitude ?? (row.location && typeof row.location === 'object' ? row.location.lat : undefined);
  const rowLng = row.lng ?? row.longitude ?? (row.location && typeof row.location === 'object' ? row.location.lng : undefined);
  const lat = (rowLat !== undefined && rowLat !== null && !isNaN(Number(rowLat))) ? Number(rowLat) : 17.4435;
  const lng = (rowLng !== undefined && rowLng !== null && !isNaN(Number(rowLng))) ? Number(rowLng) : 78.3582;
  const address = row.address ?? row.delivery_address ?? (row.location && typeof row.location === 'object' ? row.location.address : undefined) ?? 'Hyderabad Delivery Hub';

  const rawServiceType = (row.service_type ?? row.serviceType ?? 'FUEL').toString().trim().toUpperCase();
  const rawJobKind = (row.job_kind ?? row.jobKind ?? '').toString().trim().toUpperCase();

  let jobTitle = '';
  let resolvedJobKind: string | undefined = undefined;

  if (rawServiceType === 'TRANSPORT') {
    if (rawJobKind.includes('RETURN')) {
      resolvedJobKind = 'VEHICLE_RETURN';
      jobTitle = 'Return repaired vehicle';
    } else {
      resolvedJobKind = rawJobKind || 'VEHICLE_PICKUP';
      jobTitle = 'Vehicle pickup for repair';
    }
  } else if (rawServiceType === 'PARTS') {
    jobTitle = row.description ?? row.part_description ?? row.parts_description ?? row.fuel_type ?? row.fuelType ?? 'Spare parts delivery';
  } else {
    // FUEL = fuel_type with litres
    const fuelName = (row.fuel_type ?? row.fuelType ?? 'Fuel').toString().trim();
    const litersVal = row.liters ?? row.litres ?? row.amount ?? row.quantity;
    if (litersVal) {
      if (/(\d+)\s*(l|liters|litres)/i.test(fuelName)) {
        jobTitle = fuelName;
      } else {
        jobTitle = `${fuelName} (${litersVal}L)`;
      }
    } else {
      jobTitle = fuelName;
    }
  }

  const assignedPartner = row.assigned_partner_id ?? row.driver_id ?? row.driverId;

  const resolvedPrice = Number(row.price ?? row.total_price ?? 2200);
  const resolvedTotalAmount = row.total_amount !== undefined && row.total_amount !== null ? Number(row.total_amount) : resolvedPrice;
  const resolvedPayout = row.driver_payout !== undefined && row.driver_payout !== null ? Number(row.driver_payout) : resolvedPrice;

  return {
    id: String(row.id),
    customerId: row.customer_id ?? row.customerId ?? 'customer_supa',
    customer_id: row.customer_id ?? row.customerId ?? 'customer_supa',
    driverId: assignedPartner,
    driver_id: assignedPartner,
    assigned_partner_id: assignedPartner,
    assignedPartnerId: assignedPartner,
    assigned_partner_type: row.assigned_partner_type ?? row.assignedPartnerType ?? 'BOWSER_DRIVER',
    assignedPartnerType: row.assigned_partner_type ?? row.assignedPartnerType ?? 'BOWSER_DRIVER',
    accepted_at: row.accepted_at ?? row.acceptedAt,
    acceptedAt: row.accepted_at ?? row.acceptedAt,
    // Driver coordinates are telemetry only, never destination
    driver_lat: (row.driver_lat !== undefined && row.driver_lat !== null) ? Number(row.driver_lat) : undefined,
    driver_lng: (row.driver_lng !== undefined && row.driver_lng !== null) ? Number(row.driver_lng) : undefined,
    driver_speed_kmh: (row.driver_speed_kmh !== undefined && row.driver_speed_kmh !== null) ? Number(row.driver_speed_kmh) : undefined,
    status: (row.status ?? 'PENDING').toString().toUpperCase(),
    service_type: rawServiceType,
    serviceType: rawServiceType,
    job_kind: resolvedJobKind || (rawServiceType === 'TRANSPORT' ? 'VEHICLE_PICKUP' : undefined),
    jobKind: resolvedJobKind || (rawServiceType === 'TRANSPORT' ? 'VEHICLE_PICKUP' : undefined),
    description: row.description ?? row.part_description,
    fuelType: jobTitle,
    fuel_type: jobTitle,
    amount: Number(row.amount ?? row.liters ?? row.litres ?? 20),
    liters: Number(row.liters ?? row.litres ?? row.amount ?? 20),
    litres: Number(row.liters ?? row.litres ?? row.amount ?? 20),
    price: resolvedPrice,
    total_amount: resolvedTotalAmount,
    totalAmount: resolvedTotalAmount,
    payment_method: (row.payment_method || 'COD').toUpperCase(),
    paymentMethod: (row.payment_method || 'COD').toUpperCase(),
    payment_status: (row.payment_status || 'PENDING').toUpperCase(),
    paymentStatus: (row.payment_status || 'PENDING').toUpperCase(),
    driver_payout: resolvedPayout,
    driverPayout: resolvedPayout,
    delivery_fee: row.delivery_fee !== undefined && row.delivery_fee !== null ? Number(row.delivery_fee) : 0,
    gst_amount: row.gst_amount !== undefined && row.gst_amount !== null ? Number(row.gst_amount) : 0,
    paid_at: row.paid_at,
    collected_by: row.collected_by,
    verified_otp: row.verified_otp,
    location: {
      lat: isNaN(lat) ? 17.4435 : lat,
      lng: isNaN(lng) ? 78.3582 : lng,
      address,
    },
    handshake_otp: undefined,
    otp: undefined,
    delivery_otp: undefined,
    completed_at: row.completed_at ?? row.delivered_at ?? row.completedAt,
    source_app: row.source_app ?? row.sourceApp ?? row.applet_id ?? (String(row.customer_id || '').includes('ee2e') ? 'ee2e6063-3db0-4d3c-b767-c5c103cedc79' : undefined),
    sourceAppUrl: (row.source_app || row.applet_id || String(row.customer_id || '').includes('ee2e')) ? 'https://ai.studio/apps/ee2e6063-3db0-4d3c-b767-c5c103cedc79' : undefined,
    customer_name: row.customer_name ?? row.customerName ?? (String(row.source_app || row.customer_id || '').includes('ee2e') ? 'Customer App (ee2e6063)' : undefined),
    customer_phone: row.customer_phone ?? row.customerPhone,
    createdAt: row.created_at ?? row.createdAt ?? new Date().toISOString(),
    created_at: row.created_at ?? row.createdAt ?? new Date().toISOString(),
    updatedAt: row.updated_at ?? row.updatedAt ?? new Date().toISOString(),
    updated_at: row.updated_at ?? row.updatedAt ?? new Date().toISOString(),
  };
}

export interface KeyValidationResult {
  isValid: boolean;
  isRegionCode: boolean;
  isPlaceholder: boolean;
  formatType: 'jwt' | 'publishable' | 'region' | 'placeholder' | 'unknown';
  message: string;
}

/**
 * Validates whether the provided Supabase key is a valid Anon/Public key
 * or accidentally set to the cloud region code (e.g. ap-southeast-1).
 */
export function validateSupabaseAnonKey(key: string): KeyValidationResult {
  const clean = (key || '').trim();
  if (!clean || clean === 'YOUR_SUPABASE_ANON_KEY') {
    return {
      isValid: false,
      isRegionCode: false,
      isPlaceholder: true,
      formatType: 'placeholder',
      message: 'Anon Key is empty or placeholder.',
    };
  }

  // Common AWS/GCP region identifiers accidentally entered instead of anon key
  const regionPattern = /^(ap|us|eu|sa|ca|af|me|il)-(southeast|northeast|south|central|east|west|north)-[0-9]+$/i;
  if (regionPattern.test(clean) || clean.toLowerCase() === 'ap-southeast-1') {
    return {
      isValid: false,
      isRegionCode: true,
      isPlaceholder: false,
      formatType: 'region',
      message: `'${clean}' is a cloud region identifier (Asia Pacific - Singapore), NOT a Supabase Anon Key.`,
    };
  }

  // Supabase JWT starts with 'eyJ' and has 3 parts (header.payload.signature)
  if (clean.startsWith('eyJ') && clean.split('.').length >= 3) {
    return {
      isValid: true,
      isRegionCode: false,
      isPlaceholder: false,
      formatType: 'jwt',
      message: 'Valid JWT Anon Key format.',
    };
  }

  // Newer Supabase publishable / secret key format
  if (
    clean.startsWith('sb_publishable_') ||
    clean.startsWith('sbp_') ||
    clean.startsWith('sb_secret_') ||
    clean.startsWith('sb_')
  ) {
    return {
      isValid: true,
      isRegionCode: false,
      isPlaceholder: false,
      formatType: 'publishable',
      message: 'Valid Supabase Key format.',
    };
  }

  return {
    isValid: false,
    isRegionCode: false,
    isPlaceholder: false,
    formatType: 'unknown',
    message: 'Key must start with sb_publishable_, sb_secret_, or eyJ.',
  };
}

/**
 * Checks connection status to Supabase instance with detailed Invalid API diagnostics
 */
export async function testSupabaseConnection(): Promise<{
  connected: boolean;
  message: string;
  hasOrdersTable: boolean;
  activeUrl: string;
  projectId: string;
  source: string;
  isFromEnv: boolean;
  isInvalidApiKey?: boolean;
  isRegionKey?: boolean;
  directDashboardUrl: string;
}> {
  const config = getEffectiveSupabaseConfig();
  const directDashboardUrl = `https://supabase.com/dashboard/project/${config.projectId}/settings/api`;
  const keyValidation = validateSupabaseAnonKey(config.key);

  // Immediate diagnosis if region was entered as anon key
  if (keyValidation.isRegionCode) {
    return {
      connected: false,
      message: `Invalid API: '${config.key}' is the AWS server region, NOT the Supabase Anon Key.`,
      hasOrdersTable: false,
      activeUrl: config.url,
      projectId: config.projectId,
      source: config.source,
      isFromEnv: config.isFromEnv,
      isInvalidApiKey: true,
      isRegionKey: true,
      directDashboardUrl,
    };
  }

  const client = getSupabaseClient();
  try {
    const { data, error } = await client
      .from('orders')
      .select('id, status')
      .limit(1);

    if (error) {
      const errorMsg = error.message || 'Supabase request returned error';
      const isInvalidKey = 
        errorMsg.toLowerCase().includes('invalid api') || 
        errorMsg.toLowerCase().includes('jwt') ||
        errorMsg.toLowerCase().includes('unauthorized') ||
        error.code === 'PGRST301';

      return {
        connected: false,
        message: errorMsg,
        hasOrdersTable: !errorMsg.includes('does not exist'),
        activeUrl: config.url,
        projectId: config.projectId,
        source: config.source,
        isFromEnv: config.isFromEnv,
        isInvalidApiKey: isInvalidKey,
        isRegionKey: false,
        directDashboardUrl,
      };
    }
    return {
      connected: true,
      message: 'Successfully connected to live Supabase orders table',
      hasOrdersTable: true,
      activeUrl: config.url,
      projectId: config.projectId,
      source: config.source,
      isFromEnv: config.isFromEnv,
      isInvalidApiKey: false,
      isRegionKey: false,
      directDashboardUrl,
    };
  } catch (err: any) {
    const errMsg = err?.message || String(err) || 'Network / Auth error connecting to Supabase';
    const isInvalidKey = errMsg.toLowerCase().includes('invalid api') || errMsg.toLowerCase().includes('jwt');
    return {
      connected: false,
      message: errMsg,
      hasOrdersTable: false,
      activeUrl: config.url,
      projectId: config.projectId,
      source: config.source,
      isFromEnv: config.isFromEnv,
      isInvalidApiKey: isInvalidKey,
      isRegionKey: keyValidation.isRegionCode,
      directDashboardUrl,
    };
  }
}

/**
 * Fetch pending orders directly from Supabase.
 * Ignores rows where service_type = 'MAINTENANCE' (repair jobs).
 * All other rows (FUEL, PARTS, TRANSPORT) are delivery jobs.
 */
export async function fetchPendingOrdersFromSupabase(
  _workerRole?: string
): Promise<Order[]> {
  const client = getSupabaseClient();
  try {
    const { data, error } = await client
      .from('orders')
      .select('*')
      .or('status.eq.PENDING,status.eq.DISPATCHED,status.eq.ACCEPTED');

    if (error) {
      console.warn('[Supabase] Fetch orders notice:', error.message);
      return [];
    }

    // Ignore rows where service_type = 'MAINTENANCE' (repair jobs). All other rows (FUEL, PARTS, TRANSPORT) are delivery jobs.
    return (data || [])
      .filter(isDeliveryOrder)
      .map(normalizeSupabaseOrder);
  } catch (err) {
    console.warn('[Supabase] Fetch pending orders error:', err);
    return [];
  }
}

/**
 * Subscribe in real-time to the 'orders' table for incoming delivery requests.
 * Ignores rows where service_type = 'MAINTENANCE' (repair jobs).
 * All other rows (FUEL, PARTS, TRANSPORT) are delivery jobs.
 * Real-time INSERT events pop up instantly on the screen without refreshing.
 */
export function subscribeToSupabasePendingOrders(
  onOrdersChange: (orders: Order[]) => void,
  onIncomingPendingOrder?: (order: Order) => void,
  _workerRole?: string
): { unsubscribe: () => void } {
  const client = getSupabaseClient();

  let activeOrders: Map<string, Order> = new Map();

  const emit = () => {
    const list = Array.from(activeOrders.values()).filter(
      o => (
        o.status === 'PENDING' || 
        o.status === OrderStatus.PENDING || 
        o.status === 'DISPATCHED' || 
        o.status === 'ACCEPTED'
      ) && isDeliveryOrder(o)
    );
    onOrdersChange(list);
  };

  // 1. Initial fetch from Supabase (ignoring MAINTENANCE rows)
  fetchPendingOrdersFromSupabase().then((orders) => {
    orders.forEach(o => {
      if (isDeliveryOrder(o)) {
        activeOrders.set(o.id, o);
      }
    });
    emit();
  });

  // 2. Real-time Channel Subscription: listens to INSERT, UPDATE, DELETE on orders
  const channelName = `realtime-orders-feed-${Date.now()}`;
  let channel: RealtimeChannel;

  try {
    channel = client
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
        },
        (payload) => {
          const { eventType, new: newRecord, old: oldRecord } = payload as any;

          if (eventType === 'INSERT') {
            if (newRecord) {
              // Ignore rows where service_type = 'MAINTENANCE' (repair jobs)
              if (!isDeliveryOrder(newRecord)) {
                return;
              }
              const order = normalizeSupabaseOrder(newRecord);
              const statusUpper = (order.status || '').toUpperCase();
              if (statusUpper === 'PENDING') {
                activeOrders.set(order.id, order);
                emit();
                // Pop up instantly on screen with audible ringtone
                if (onIncomingPendingOrder) {
                  onIncomingPendingOrder(order);
                }
              }
            }
          } else if (eventType === 'UPDATE') {
            if (newRecord) {
              // If updated to MAINTENANCE, remove from active feed
              if (!isDeliveryOrder(newRecord)) {
                if (activeOrders.has(String(newRecord.id))) {
                  activeOrders.delete(String(newRecord.id));
                  emit();
                }
                return;
              }
              const order = normalizeSupabaseOrder(newRecord);
              const statusUpper = (order.status || '').toUpperCase();
              if (statusUpper === 'PENDING' || statusUpper === 'DISPATCHED' || statusUpper === 'ACCEPTED') {
                activeOrders.set(order.id, order);
              } else {
                // If it changed to COMPLETED or CANCELLED, remove from pending feed
                activeOrders.delete(order.id);
              }
              emit();
            }
          } else if (eventType === 'DELETE') {
            if (oldRecord && oldRecord.id) {
              activeOrders.delete(String(oldRecord.id));
              emit();
            }
          }
        }
      )
      .subscribe((status, err) => {
        if (err) {
          console.warn('[Supabase Realtime] Channel status error:', status, err);
        } else {
          console.info('[Supabase Realtime] Channel connected:', status);
        }
      });
  } catch (err) {
    console.warn('[Supabase Realtime] Setup error:', err);
  }

  return {
    unsubscribe: () => {
      try {
        if (channel) {
          client.removeChannel(channel);
        }
      } catch (e) {
        console.error(e);
      }
    },
  };
}

export interface FugoCompleteOrderResult {
  success: boolean;
  ok?: boolean;
  error?: string;
  code?: string;
  attempts_left?: number;
  minutes_left?: number;
  amount_due?: number;
  method?: string;
  order?: Order;
}

function isMissingRpcError(err: any): boolean {
  if (!err) return false;
  if (err.code === 'PGRST202') return true;
  const msg = String(err.message || err.details || '').toLowerCase();
  return (
    msg.includes('schema cache') ||
    msg.includes('could not find the function') ||
    msg.includes('searched for the function') ||
    msg.includes('fugo_accept_order') ||
    msg.includes('fugo_complete_order')
  );
}

/**
 * 1. Accepting a job:
 * Calls supabase.rpc('fugo_accept_order', { p_order_id, p_driver_id }).
 * If the database function is not yet in the schema cache (PGRST202), automatically
 * falls back to direct defensive update on public.orders with status 'DISPATCHED'.
 * Returns { ok, error, order }. If error is ALREADY_TAKEN, shows "Another driver took this job".
 */
export async function acceptSupabaseOrderToInTransit(
  orderId: string,
  driverId: string = 'HYD-NALLAGANDLA-01',
  _partnerType?: string
): Promise<{ success: boolean; error?: string; alreadyTaken?: boolean; order?: Order }> {
  const client = getSupabaseClient();
  const effectiveDriverId = (driverId || 'HYD-NALLAGANDLA-01').trim();

  try {
    const { data, error } = await client.rpc('fugo_accept_order', {
      p_order_id: String(orderId),
      p_driver_id: effectiveDriverId,
    });

    if (error) {
      if (isMissingRpcError(error)) {
        console.warn('[Supabase] fugo_accept_order RPC not in schema cache (PGRST202); falling back to direct defensive update on orders table');
        const now = new Date().toISOString();
        
        // Defensive direct update on public.orders table
        const { data: updateData, error: updateError } = await client
          .from('orders')
          .update({
            status: 'DISPATCHED',
            assigned_partner_id: effectiveDriverId,
            driver_id: effectiveDriverId,
            accepted_at: now,
            updated_at: now,
          })
          .eq('id', String(orderId))
          .eq('status', 'PENDING')
          .select();

        if (updateError) {
          console.warn('[Supabase] Full update failed, retrying minimal essential fields:', updateError.message);
          const { data: minData, error: minError } = await client
            .from('orders')
            .update({
              status: 'DISPATCHED',
              assigned_partner_id: effectiveDriverId,
              accepted_at: now,
            })
            .eq('id', String(orderId))
            .eq('status', 'PENDING')
            .select();

          if (minError) {
            console.error('[Supabase] Direct accept failed:', minError);
            return { success: false, error: minError.message };
          }

          if (!minData || minData.length === 0) {
            return {
              success: false,
              alreadyTaken: true,
              error: 'Another driver took this job',
            };
          }

          return {
            success: true,
            order: normalizeSupabaseOrder(minData[0]),
          };
        }

        if (!updateData || updateData.length === 0) {
          return {
            success: false,
            alreadyTaken: true,
            error: 'Another driver took this job',
          };
        }

        return {
          success: true,
          order: normalizeSupabaseOrder(updateData[0]),
        };
      }

      console.error('[Supabase] fugo_accept_order RPC error:', error);
      return { success: false, error: error.message };
    }

    if (!data) {
      return { success: false, error: 'No response from server' };
    }

    if (data.error === 'ALREADY_TAKEN') {
      const msg = 'Another driver took this job';
      return { 
        success: false, 
        alreadyTaken: true, 
        error: msg 
      };
    }

    if (!data.ok) {
      const msg = data.error || 'Failed to accept order';
      return { success: false, error: msg };
    }

    const acceptedOrder = normalizeSupabaseOrder(data.order);
    return { success: true, order: acceptedOrder };
  } catch (err: any) {
    console.error('Full error in acceptSupabaseOrderToInTransit:', err);
    const errMsg = err?.message || 'Network error updating Supabase';
    return { success: false, error: errMsg };
  }
}

export const acceptOrder = acceptSupabaseOrderToInTransit;
export const handleAccept = acceptSupabaseOrderToInTransit;

/**
 * 2. Finishing a delivery:
 * Calls supabase.rpc('fugo_complete_order', { p_order_id, p_otp, p_driver_id, p_collected }).
 * If the database function is not yet in the schema cache (PGRST202), automatically
 * falls back to direct order verification against handshake_otp and marks COMPLETED.
 */
export async function completeSupabaseOrderWithOtp(
  orderId: string,
  enteredOtp: string,
  driverId: string = 'HYD-NALLAGANDLA-01',
  isCollected: boolean = false
): Promise<FugoCompleteOrderResult> {
  const client = getSupabaseClient();
  const cleanInput = enteredOtp.trim();
  const effectiveDriverId = (driverId || 'HYD-NALLAGANDLA-01').trim();

  try {
    const { data, error } = await client.rpc('fugo_complete_order', {
      p_order_id: String(orderId),
      p_otp: cleanInput,
      p_driver_id: effectiveDriverId,
      p_collected: Boolean(isCollected),
    });

    if (error) {
      if (isMissingRpcError(error)) {
        console.warn('[Supabase] fugo_complete_order RPC not in schema cache (PGRST202); executing defensive completion fallback on orders table');
        
        // 1. Query order row to verify OTP
        const { data: orderRow, error: fetchErr } = await client
          .from('orders')
          .select('*')
          .eq('id', String(orderId))
          .single();

        if (fetchErr || !orderRow) {
          return { success: false, ok: false, error: fetchErr?.message || 'Order not found in database' };
        }

        const expectedOtp = String(orderRow.handshake_otp || orderRow.delivery_otp || orderRow.otp || '').trim();
        if (expectedOtp && cleanInput !== expectedOtp) {
          return {
            success: false,
            ok: false,
            error: 'Wrong code, please check with customer',
            code: 'WRONG_OTP',
            attempts_left: 3,
          };
        }

        // 2. Mark order as completed
        const now = new Date().toISOString();
        const { data: compRows, error: compErr } = await client
          .from('orders')
          .update({
            status: 'COMPLETED',
            completed_at: now,
            verified_otp: cleanInput,
            payment_status: 'PAID',
            paid_at: now,
            collected_by: effectiveDriverId,
            updated_at: now,
          })
          .eq('id', String(orderId))
          .select();

        if (compErr) {
          console.warn('[Supabase] Full completion update failed, attempting minimal fields:', compErr.message);
          const { data: minComp, error: minCompErr } = await client
            .from('orders')
            .update({
              status: 'COMPLETED',
              completed_at: now,
            })
            .eq('id', String(orderId))
            .select();

          if (minCompErr) {
            return { success: false, ok: false, error: minCompErr.message };
          }

          return {
            success: true,
            ok: true,
            order: minComp?.[0] ? normalizeSupabaseOrder(minComp[0]) : undefined,
          };
        }

        return {
          success: true,
          ok: true,
          order: compRows?.[0] ? normalizeSupabaseOrder(compRows[0]) : undefined,
        };
      }

      console.warn('[Supabase] fugo_complete_order RPC error:', error);
      return { success: false, error: error.message, code: error.code };
    }

    if (!data) {
      return { success: false, error: 'No response from server' };
    }

    if (data.ok) {
      return {
        success: true,
        ok: true,
        order: data.order ? normalizeSupabaseOrder(data.order) : undefined,
      };
    }

    let userFacingMessage = data.error || 'Failed to complete order';
    if (data.error === 'WRONG_OTP') {
      const left = data.attempts_left ?? 0;
      userFacingMessage = `Wrong code, ${left} ${left === 1 ? 'try' : 'tries'} left`;
    } else if (data.error === 'LOCKED') {
      const mins = data.minutes_left ?? 30;
      userFacingMessage = `Too many wrong codes. Try again in ${mins} minutes`;
    } else if (data.error === 'PAYMENT_NOT_COLLECTED') {
      userFacingMessage = `Payment of ₹${data.amount_due ?? 0} not collected. Confirm cash or UPI received first.`;
    } else if (data.error === 'NOT_YOUR_ORDER') {
      userFacingMessage = 'This order is not assigned to your driver account.';
    } else if (data.error === 'NOT_IN_TRANSIT') {
      userFacingMessage = `Order is not in transit (status: ${data.status || 'unknown'})`;
    } else if (data.error === 'NOT_FOUND') {
      userFacingMessage = 'Order not found in database';
    } else if (data.error === 'NO_OTP_ON_FILE') {
      userFacingMessage = 'No delivery code on file for this order';
    } else if (data.error === 'NOT_A_DELIVERY') {
      userFacingMessage = 'This order is not a delivery job';
    }

    return {
      success: false,
      ok: false,
      error: userFacingMessage,
      code: data.error,
      attempts_left: data.attempts_left,
      minutes_left: data.minutes_left,
      amount_due: data.amount_due,
      method: data.method,
    };
  } catch (err: any) {
    console.warn('[Supabase] completeSupabaseOrderWithOtp exception:', err);
    return { success: false, error: err?.message || 'Network error completing order' };
  }
}

/**
 * 3. Read app_settings (columns key and value):
 * Reads merchant_vpa, merchant_name, gstin, transport_fee
 */
export interface AppSettings {
  merchant_name: string;
  merchant_vpa: string;
  gstin: string;
  transport_fee: string;
}

let cachedAppSettings: AppSettings | null = null;
let appSettingsPromise: Promise<AppSettings> | null = null;

export async function fetchAppSettings(): Promise<AppSettings> {
  if (cachedAppSettings) return cachedAppSettings;
  if (appSettingsPromise) return appSettingsPromise;

  appSettingsPromise = (async () => {
    const defaultSettings: AppSettings = {
      merchant_name: 'Fugo',
      merchant_vpa: '6300352955@ibl',
      gstin: '',
      transport_fee: '100',
    };

    try {
      const client = getSupabaseClient();
      const { data, error } = await client
        .from('app_settings')
        .select('key, value');

      if (!error && data) {
        data.forEach((row: { key: string; value: string }) => {
          if (row.key === 'merchant_name') defaultSettings.merchant_name = row.value || 'Fugo';
          if (row.key === 'merchant_vpa') defaultSettings.merchant_vpa = row.value || '';
          if (row.key === 'gstin') defaultSettings.gstin = row.value || '';
          if (row.key === 'transport_fee') defaultSettings.transport_fee = row.value || '0';
        });
      }
    } catch (err) {
      console.warn('[Supabase] Error reading app_settings:', err);
    }
    cachedAppSettings = defaultSettings;
    return defaultSettings;
  })();

  return appSettingsPromise;
}

/**
 * 4. Real location updates for IN_TRANSIT order:
 * Updates driver_lat, driver_lng and driver_speed_kmh on public.orders
 */
export async function updateOrderDriverLocation(
  orderId: string,
  lat: number,
  lng: number,
  speedKmh?: number | null
): Promise<void> {
  const client = getSupabaseClient();
  const updatePayload: Record<string, any> = {
    driver_lat: lat,
    driver_lng: lng,
    last_updated_at: new Date().toISOString(),
  };
  if (speedKmh !== undefined && speedKmh !== null && !isNaN(speedKmh)) {
    updatePayload.driver_speed_kmh = Math.max(0, Math.round(speedKmh));
  }
  try {
    await client.from('orders').update(updatePayload).eq('id', orderId);
  } catch (err) {
    console.warn('[Supabase] updateOrderDriverLocation error:', err);
  }
}

/**
 * 6. Earnings:
 * Add up driver_payout (use price if it is empty) of this driver's COMPLETED jobs.
 */
export async function fetchDriverCompletedEarnings(driverId: string = 'HYD-NALLAGANDLA-01'): Promise<{ totalEarnings: number; completedCount: number; jobs: Order[] }> {
  const client = getSupabaseClient();
  const effectiveDriverId = (driverId || 'HYD-NALLAGANDLA-01').trim();
  try {
    const { data, error } = await client
      .from('orders')
      .select('*')
      .eq('status', 'COMPLETED')
      .or(`driver_id.eq.${effectiveDriverId},assigned_partner_id.eq.${effectiveDriverId}`);

    if (error || !data) {
      return { totalEarnings: 0, completedCount: 0, jobs: [] };
    }

    const completed = data.map(normalizeSupabaseOrder);
    const totalEarnings = completed.reduce((sum, job) => {
      const payout = (job.driver_payout !== undefined && job.driver_payout !== null && !isNaN(job.driver_payout))
        ? job.driver_payout
        : (job.price || 0);
      return sum + payout;
    }, 0);

    return { totalEarnings, completedCount: completed.length, jobs: completed };
  } catch (err) {
    console.warn('[Supabase] fetchDriverCompletedEarnings error:', err);
    return { totalEarnings: 0, completedCount: 0, jobs: [] };
  }
}


/**
 * Creates/Inserts a new PENDING order in Supabase.
 * Perfect for pushing orders into the live Supabase stream.
 */
export async function insertSupabaseOrder(orderData: Partial<Order>): Promise<{
  success: boolean;
  order?: Order;
  error?: string;
}> {
  const client = getSupabaseClient();
  const generatedId = orderData.id || `ord_supa_${Date.now()}`;
  const generatedOtp = String(Math.floor(1000 + Math.random() * 9000));

  // In insertSupabaseOrder send service_type: 'FUEL'
  const liters = orderData.amount || orderData.liters || 30;
  const rawFuel = orderData.fuelType || orderData.fuel_type || 'High Speed Diesel';
  const fuelWithLitres = /(\d+)\s*(l|liters|litres)/i.test(rawFuel)
    ? rawFuel
    : `${rawFuel} (${liters}L)`;

  const payload: any = {
    id: generatedId,
    customer_id: orderData.customerId || orderData.customer_id || 'cust_gachibowli',
    status: 'PENDING',
    service_type: 'FUEL', // In insertSupabaseOrder send service_type: 'FUEL'
    fuel_type: fuelWithLitres,
    amount: liters,
    liters: liters,
    price: orderData.price || 2850,
    address: orderData.location?.address || 'Gachibowli Circle, Hyderabad',
    lat: orderData.location?.lat || 17.4435,
    lng: orderData.location?.lng || 78.3582,
    otp: generatedOtp,
    handshake_otp: generatedOtp,
    delivery_otp: generatedOtp,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  try {
    const { data, error } = await client
      .from('orders')
      .insert([payload])
      .select()
      .single();

    if (error) {
      console.warn('[Supabase] Insert order notice:', error.message);
      // Return normalized local object so the app can continue seamlessly
      const fallbackOrder = normalizeSupabaseOrder(payload);
      return { success: false, order: fallbackOrder, error: error.message };
    }

    return { success: true, order: normalizeSupabaseOrder(data || payload) };
  } catch (err: any) {
    const fallbackOrder = normalizeSupabaseOrder(payload);
    return { success: false, order: fallbackOrder, error: err?.message };
  }
}

/**
 * Subscribe in real-time to changes on a specific order by ID
 * Used when an order is placed to track driver assignment, status changes, GPS pings, and completion in real-time.
 */
export function subscribeToOrderRealtime(
  orderId: string,
  onOrderUpdate: (order: Order) => void
): { unsubscribe: () => void } {
  const client = getSupabaseClient();
  const channelName = `realtime-order-${orderId}-${Date.now()}`;
  let channel: RealtimeChannel;

  try {
    channel = client
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `id=eq.${orderId}`,
        },
        (payload) => {
          const { new: newRecord } = payload as any;
          if (newRecord) {
            if (!isDeliveryOrder(newRecord)) return;
            const order = normalizeSupabaseOrder(newRecord);
            onOrderUpdate(order);
          }
        }
      )
      .subscribe((status, err) => {
        if (err) {
          console.warn(`[Supabase Realtime] Order ${orderId} subscription status:`, status, err);
        } else {
          console.info(`[Supabase Realtime] Subscribed to order ${orderId}:`, status);
        }
      });
  } catch (err) {
    console.warn('[Supabase Realtime] Error setting up order subscription:', orderId, err);
  }

  return {
    unsubscribe: () => {
      try {
        if (channel) {
          client.removeChannel(channel);
        }
      } catch (e) {
        console.error(e);
      }
    },
  };
}

/**
 * When an order is placed:
 * 1. Inserts it into the 'orders' table with status 'PENDING'
 * 2. Generates a 4-digit OTP (1000 - 9999)
 * 3. Subscribes in real-time to changes on that order
 */
export async function placeOrderWithRealtimeSubscription(
  orderData: Partial<Order>,
  onOrderUpdate?: (order: Order) => void
): Promise<{
  success: boolean;
  order: Order;
  unsubscribe?: () => void;
  error?: string;
}> {
  const client = getSupabaseClient();
  const generatedId = orderData.id || `ord_supa_${Date.now()}`;
  // 4-digit OTP (1000 - 9999)
  const otp4Digit = String(Math.floor(1000 + Math.random() * 9000));

  const liters = orderData.amount || orderData.liters || 25;
  const rawFuel = orderData.fuelType || orderData.fuel_type || 'High Speed Diesel';
  const fuelWithLitres = /(\d+)\s*(l|liters|litres)/i.test(rawFuel)
    ? rawFuel
    : `${rawFuel} (${liters}L)`;

  const payload: any = {
    id: generatedId,
    customer_id: orderData.customerId || orderData.customer_id || 'cust_gachibowli',
    status: 'PENDING',
    service_type: 'FUEL',
    fuel_type: fuelWithLitres,
    amount: liters,
    liters: liters,
    price: orderData.price || 2400,
    address: orderData.location?.address || 'Gachibowli Circle, Hyderabad',
    lat: orderData.location?.lat ?? 17.4435,
    lng: orderData.location?.lng ?? 78.3582,
    otp: otp4Digit, // 4-digit OTP
    delivery_otp: otp4Digit,
    handshake_otp: otp4Digit,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  let finalOrder: Order = normalizeSupabaseOrder(payload);
  let errorMsg: string | undefined = undefined;

  try {
    const { data, error } = await client
      .from('orders')
      .insert([payload])
      .select()
      .single();

    if (error) {
      console.warn('[Supabase] placeOrderWithRealtimeSubscription insert notice:', error.message);
      errorMsg = error.message;
    } else if (data) {
      finalOrder = normalizeSupabaseOrder(data);
    }
  } catch (err: any) {
    console.warn('[Supabase] placeOrderWithRealtimeSubscription network notice:', err);
    errorMsg = err?.message;
  }

  // Subscribe to real-time changes on this order
  let unsubscribeFn: (() => void) | undefined = undefined;
  try {
    const subscription = subscribeToOrderRealtime(finalOrder.id, (updatedOrder) => {
      if (onOrderUpdate) {
        onOrderUpdate(updatedOrder);
      }
    });
    unsubscribeFn = subscription.unsubscribe;
  } catch (err) {
    console.warn('[Supabase] Subscription error for placed order:', err);
  }

  return {
    success: !errorMsg,
    order: finalOrder,
    unsubscribe: unsubscribeFn,
    error: errorMsg,
  };
}

/**
 * Inserts directly into public.orders table and returns actual error if occurred.
 */
export async function handleOrderSubmit(orderPayload?: any): Promise<{ success: boolean; data?: any; error?: string }> {
  const client = getSupabaseClient();
  const generatedId = orderPayload?.id || `ord_supa_${Date.now()}`;
  const generatedOtp = String(Math.floor(1000 + Math.random() * 9000));

  const payload: any = {
    id: generatedId,
    customer_id: orderPayload?.customerId || orderPayload?.customer_id || 'cust_gachibowli',
    status: 'PENDING',
    service_type: orderPayload?.service_type || orderPayload?.serviceType || 'FUEL',
    fuel_type: orderPayload?.fuel_type || orderPayload?.fuelType || 'High Speed Diesel (30L)',
    amount: orderPayload?.amount || orderPayload?.liters || 30,
    liters: orderPayload?.amount || orderPayload?.liters || 30,
    price: orderPayload?.price || 2850,
    address: orderPayload?.location?.address || orderPayload?.address || 'Gachibowli Circle, Hyderabad',
    lat: orderPayload?.location?.lat ?? orderPayload?.lat ?? 17.4435,
    lng: orderPayload?.location?.lng ?? orderPayload?.lng ?? 78.3582,
    otp: generatedOtp,
    handshake_otp: generatedOtp,
    delivery_otp: generatedOtp,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    ...(orderPayload && typeof orderPayload === 'object' ? orderPayload : {}),
  };

  try {
    const { data, error } = await client
      .from('orders')
      .insert([payload])
      .select()
      .single();

    if (error) {
      console.warn('[Supabase] handleOrderSubmit insert notice:', error.message);
      return { success: false, error: error.message };
    }
    return { success: true, data };
  } catch (err: any) {
    const errorMsg = err?.message || String(err);
    console.warn('[Supabase] handleOrderSubmit exception:', errorMsg);
    return { success: false, error: errorMsg };
  }
}
