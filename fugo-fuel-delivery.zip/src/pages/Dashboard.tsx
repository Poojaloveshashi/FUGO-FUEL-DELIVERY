import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Navigation, 
  AlertCircle,
  X, 
  Check, 
  ChevronRight, 
  Clock, 
  Power, 
  Volume2, 
  Radio, 
  KeyRound, 
  Truck, 
  CheckCircle2, 
  WifiOff, 
  RefreshCw,
  Wallet,
  ShieldCheck,
  Calendar
} from 'lucide-react';
import MapView from '../components/Map';
import SlotBooking from '../components/SlotBooking';
import OtpVerificationModal from '../components/OtpVerificationModal';
import IncomingJobDialog from '../components/IncomingJobDialog';
import { 
  UserProfile, 
  Order, 
  OrderStatus, 
  UserStatus, 
  Location 
} from '../types';
import { 
  acceptSupabaseOrderToInTransit,
  completeSupabaseOrderWithOtp,
  updateOrderDriverLocation,
  fetchDriverCompletedEarnings,
  fetchPendingOrdersFromSupabase,
  subscribeToSupabasePendingOrders,
  isDeliveryOrder,
  FugoCompleteOrderResult
} from '../lib/supabase';
import { 
  updateProfileStatus,
  subscribeToMyActiveDeliveries
} from '../services/store';
import { calculateDistanceKm, cn } from '../lib/utils';
import { FUEL_SALES_ENABLED } from '../config';

interface DashboardProps {
  profile: UserProfile;
}

export default function Dashboard({ profile }: DashboardProps) {
  const isIndia = ['Asia/Calcutta', 'Asia/Kolkata'].includes(Intl.DateTimeFormat().resolvedOptions().timeZone);
  const currencySymbol = isIndia ? '₹' : '$';

  // Driver online / offline status
  const [isDriverOnline, setIsDriverOnline] = useState<boolean>(() => {
    return profile.status !== UserStatus.OFFLINE;
  });

  // Internet connection status
  const [isInternetConnected, setIsInternetConnected] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });

  const [availableJobs, setAvailableJobs] = useState<Order[]>([]);
  const [myOrders, setMyOrders] = useState<Order[]>([]);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [driverLocation, setDriverLocation] = useState<Location | null>(null);
  const [showSlotBooking, setShowSlotBooking] = useState(false);
  const [hasBookedSlot, setHasBookedSlot] = useState(false);
  const [reachedLocationJobIds, setReachedLocationJobIds] = useState<Set<string>>(new Set());

  // Real-time Incoming Job & Dialog State
  const [activeIncomingJob, setActiveIncomingJob] = useState<Order | null>(null);
  const [declinedJobIds, setDeclinedJobIds] = useState<Set<string>>(new Set());

  // Handover OTP Modal State
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [orderForOtp, setOrderForOtp] = useState<Order | null>(null);
  const [driverEarnings, setDriverEarnings] = useState<number>(0);
  const [completedJobCount, setCompletedJobCount] = useState<number>(0);

  // Real GPS coordinates ref for 5-second location pinging
  const latestCoordsRef = useRef<{ lat: number; lng: number; speedKmh: number | null }>({
    lat: profile.location?.lat ?? 17.4435,
    lng: profile.location?.lng ?? 78.3582,
    speedKmh: null,
  });

  // Internet connection event listeners
  useEffect(() => {
    const handleOnline = () => setIsInternetConnected(true);
    const handleOffline = () => setIsInternetConnected(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Update driver online / offline status
  const handleToggleOnline = async () => {
    const nextStatus = !isDriverOnline;
    setIsDriverOnline(nextStatus);
    try {
      await updateProfileStatus(nextStatus ? UserStatus.ONLINE : UserStatus.OFFLINE);
    } catch (err) {
      console.warn('Status toggle error:', err);
    }
  };

  // Fetch driver earnings (sums driver_payout or price for COMPLETED jobs)
  const refreshEarnings = () => {
    const effectiveDriverId = profile.uid || 'HYD-NALLAGANDLA-01';
    fetchDriverCompletedEarnings(effectiveDriverId).then((res) => {
      setDriverEarnings(res.totalEarnings);
      setCompletedJobCount(res.completedCount);
    });
  };

  useEffect(() => {
    refreshEarnings();
  }, [profile.uid]);

  // Real GPS tracking via navigator.geolocation.watchPosition (No simulated movement)
  useEffect(() => {
    if (!navigator.geolocation) return;

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const speedKmh = pos.coords.speed !== null && !isNaN(pos.coords.speed)
          ? Math.max(0, Math.round(pos.coords.speed * 3.6))
          : null;

        latestCoordsRef.current = { lat, lng, speedKmh };
        setDriverLocation({
          lat,
          lng,
          address: profile.location?.address || 'Current Position',
        });
      },
      (err) => {
        console.warn('GPS position watch notice:', err.message);
      },
      {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 15000,
      }
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, [profile.location?.address]);

  // Active delivery: updates driver_lat, driver_lng and driver_speed_kmh every 5 seconds
  const activeDeliveryJob = myOrders.find(
    (o) =>
      o.status === OrderStatus.IN_TRANSIT ||
      o.status === 'IN_TRANSIT' ||
      o.status === 'ASSIGNED' ||
      o.status === 'ACCEPTED' ||
      o.status === 'DISPATCHED'
  );

  useEffect(() => {
    if (!activeDeliveryJob) return;

    const intervalId = setInterval(() => {
      const coords = latestCoordsRef.current;
      if (coords && coords.lat && coords.lng) {
        updateOrderDriverLocation(
          activeDeliveryJob.id,
          coords.lat,
          coords.lng,
          coords.speedKmh
        );
      }
    }, 5000);

    return () => clearInterval(intervalId);
  }, [activeDeliveryJob?.id]);

  // Subscribe to driver's active deliveries
  useEffect(() => {
    const effectiveDriverId = profile.uid || 'HYD-NALLAGANDLA-01';
    const unsub = subscribeToMyActiveDeliveries(effectiveDriverId, (orders) => {
      setMyOrders(orders);
    });
    return () => unsub();
  }, [profile.uid]);

  // Subscribe to available jobs in real-time
  useEffect(() => {
    if (!isDriverOnline) {
      setAvailableJobs([]);
      setActiveIncomingJob(null);
      return;
    }

    const sub = subscribeToSupabasePendingOrders(
      (orders) => {
        // Filter out declined jobs and respect FUEL_SALES_ENABLED
        const valid = orders.filter((o) => {
          if (declinedJobIds.has(o.id)) return false;
          if (!FUEL_SALES_ENABLED && o.service_type === 'FUEL') return false;
          return isDeliveryOrder(o);
        });
        setAvailableJobs(valid);
      },
      (newJob) => {
        // Trigger dialog if online and eligible
        if (
          !declinedJobIds.has(newJob.id) &&
          (FUEL_SALES_ENABLED || newJob.service_type !== 'FUEL') &&
          isDeliveryOrder(newJob)
        ) {
          setActiveIncomingJob(newJob);
        }
      }
    );

    return () => sub.unsubscribe();
  }, [isDriverOnline, declinedJobIds]);

  // Accept a job
  const handleAcceptJob = async (orderId: string) => {
    const effectiveDriverId = profile.uid || 'HYD-NALLAGANDLA-01';
    setActiveIncomingJob(null);
    setErrorMessage(null);

    try {
      const res = await acceptSupabaseOrderToInTransit(orderId, effectiveDriverId);

      if (!res.success) {
        if (res.alreadyTaken || res.error?.includes('taken')) {
          setErrorMessage('Another driver took this job');
          setAvailableJobs((prev) => prev.filter((o) => o.id !== orderId));
          // Refresh list from database
          fetchPendingOrdersFromSupabase().then((jobs) => setAvailableJobs(jobs));
        } else {
          setErrorMessage(res.error || 'Failed to accept job');
        }
        return;
      }

      setSuccessMessage('Job accepted. Route active.');
      setTimeout(() => setSuccessMessage(null), 3000);

      // Refresh list
      fetchPendingOrdersFromSupabase().then((jobs) => setAvailableJobs(jobs));
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error accepting job');
    }
  };

  // Decline job
  const handleDeclineIncomingJob = (orderId: string) => {
    setDeclinedJobIds((prev) => new Set([...prev, orderId]));
    setActiveIncomingJob(null);
  };

  // Arrival marker
  const handleMarkReachedLocation = (job: Order) => {
    setReachedLocationJobIds((prev) => new Set([...prev, job.id]));
    setSuccessMessage('Arrived at customer location. Ready for payment & handover.');
    setTimeout(() => setSuccessMessage(null), 4000);
  };

  // Open Handover / Payment Modal
  const handleOpenOtpModal = (job: Order) => {
    setOrderForOtp(job);
    setShowOtpModal(true);
  };

  // Verify OTP and complete delivery
  const handleVerifyAndCompleteOtp = async (
    enteredOtp: string,
    isCollected: boolean
  ): Promise<FugoCompleteOrderResult> => {
    if (!orderForOtp) {
      return { success: false, error: 'No order selected' };
    }

    const effectiveDriverId = profile.uid || 'HYD-NALLAGANDLA-01';
    const res = await completeSupabaseOrderWithOtp(
      orderForOtp.id,
      enteredOtp,
      effectiveDriverId,
      isCollected
    );

    if (res.success) {
      setSuccessMessage('Delivery completed successfully! Payout credited.');
      setTimeout(() => setSuccessMessage(null), 4000);
      setShowOtpModal(false);
      setOrderForOtp(null);
      refreshEarnings();
    }

    return res;
  };

  return (
    <div className="flex flex-col h-full bg-black text-white relative font-sans overflow-x-hidden">
      {/* Offline banner if network drops */}
      {!isInternetConnected && (
        <div className="bg-red-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-center gap-2 tracking-wider uppercase z-[700] shadow-md">
          <WifiOff size={14} className="animate-pulse" />
          <span>No internet. Reconnecting...</span>
        </div>
      )}

      {/* Floating Alerts */}
      <AnimatePresence>
        {successMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-[600] bg-emerald-500 text-black px-5 py-3 rounded-2xl font-bold text-xs uppercase tracking-wider shadow-2xl flex items-center gap-2"
          >
            <CheckCircle2 size={16} />
            <span>{successMessage}</span>
          </motion.div>
        )}

        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-[600] bg-red-600 text-white px-5 py-3 rounded-2xl font-bold text-xs uppercase tracking-wider shadow-2xl flex items-center justify-between gap-3 max-w-md w-[90%]"
          >
            <div className="flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button onClick={() => setErrorMessage(null)} className="p-1 hover:bg-white/20 rounded">
              <X size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Header Bar */}
      <div className="p-4 sm:p-5 border-b border-white/10 bg-neutral-950/80 backdrop-blur-md flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-gold-600 to-gold-400 flex items-center justify-center text-black font-black shadow-lg shadow-gold-500/20">
            <Truck size={20} />
          </div>
          <div>
            <h1 className="font-display font-bold text-base tracking-tight uppercase italic text-white leading-none">
              {profile.displayName || 'Driver Partner'}
            </h1>
            <p className="text-[10px] text-gray-400 font-mono mt-1">
              {profile.uid.slice(0, 14)}
            </p>
          </div>
        </div>

        {/* Clean Online / Offline Switch */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleToggleOnline}
            className={cn(
              "flex items-center gap-2.5 px-4 py-2 rounded-2xl border text-xs font-bold uppercase tracking-wider transition-all shadow-md active:scale-95",
              isDriverOnline
                ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25"
                : "bg-white/5 border-white/10 text-gray-400 hover:text-white"
            )}
          >
            <div className={cn(
              "w-2.5 h-2.5 rounded-full transition-all",
              isDriverOnline ? "bg-emerald-400 animate-ping" : "bg-gray-500"
            )} />
            <span>{isDriverOnline ? 'Online' : 'Offline'}</span>
            <Power size={13} className={isDriverOnline ? "text-emerald-400" : "text-gray-500"} />
          </button>
        </div>
      </div>

      {/* Map View Area */}
      <div className="relative flex-1 min-h-[320px] bg-neutral-900 overflow-hidden">
        {(() => {
          const mapCenter = (driverLocation?.lat && driverLocation?.lng)
            ? { lat: driverLocation.lat, lng: driverLocation.lng }
            : (profile.location?.lat && profile.location?.lng)
            ? { lat: profile.location.lat, lng: profile.location.lng }
            : { lat: 17.4435, lng: 78.3582 };

          const markers: { id: string; position: { lat: number; lng: number }; type?: 'order' | 'driver' | 'customer' | 'sos' }[] = [];
          if (driverLocation?.lat && driverLocation?.lng) {
            markers.push({
              id: 'driver-marker',
              position: { lat: driverLocation.lat, lng: driverLocation.lng },
              type: 'driver',
            });
          }

          const jobsToShow = activeDeliveryJob ? [activeDeliveryJob] : availableJobs;
          jobsToShow.forEach((job) => {
            if (job.location?.lat && job.location?.lng) {
              markers.push({
                id: `job-${job.id}`,
                position: { lat: job.location.lat, lng: job.location.lng },
                type: 'order',
              });
            }
          });

          return (
            <MapView 
              center={mapCenter}
              markers={markers}
            />
          );
        })()}

        {/* Floating Quick Stats Card */}
        <div className="absolute top-4 left-4 z-20 flex gap-2">
          <div className="bg-black/80 backdrop-blur-md border border-white/10 px-3.5 py-2 rounded-2xl shadow-xl flex items-center gap-2">
            <Wallet size={15} className="text-gold-400" />
            <div className="leading-tight">
              <span className="text-[9px] text-gray-400 uppercase font-bold block">Earnings</span>
              <span className="text-xs font-black text-white font-mono">
                {currencySymbol}{driverEarnings.toLocaleString()}
              </span>
            </div>
          </div>

          <div className="bg-black/80 backdrop-blur-md border border-white/10 px-3.5 py-2 rounded-2xl shadow-xl flex items-center gap-2">
            <CheckCircle2 size={15} className="text-emerald-400" />
            <div className="leading-tight">
              <span className="text-[9px] text-gray-400 uppercase font-bold block">Delivered</span>
              <span className="text-xs font-black text-white font-mono">
                {completedJobCount}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Dispatch / Jobs Tray */}
      <div className="p-4 sm:p-5 bg-neutral-950 border-t border-white/10 z-20 max-h-[50vh] overflow-y-auto space-y-4">
        {activeDeliveryJob ? (
          /* Active Job In Transit Card */
          <div className="bg-neutral-900 border-2 border-gold-500/50 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-gold-400 animate-ping" />
                <span className="text-xs font-bold text-gold-400 uppercase tracking-wider">
                  Active Dispatch • On Route
                </span>
              </div>
              <span className="text-xs font-mono font-bold bg-white/10 px-2.5 py-1 rounded-full text-white">
                {activeDeliveryJob.id}
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <h3 className="text-lg font-black uppercase text-white font-display">
                  {activeDeliveryJob.fuelType || activeDeliveryJob.fuel_type || 'Vehicle Transport'}
                </h3>
                <p className="text-xs text-gray-300 flex items-center gap-1.5 mt-1">
                  <MapPin size={14} className="text-gold-400 shrink-0" />
                  <span className="truncate">{activeDeliveryJob.location?.address || 'Customer Location'}</span>
                </p>
              </div>

              {/* Distance calculation */}
              {(() => {
                const driverLat = latestCoordsRef.current?.lat || profile.location?.lat || 17.4435;
                const driverLng = latestCoordsRef.current?.lng || profile.location?.lng || 78.3582;
                const destLat = activeDeliveryJob.location?.lat || 17.4435;
                const destLng = activeDeliveryJob.location?.lng || 78.3582;
                const distanceKm = calculateDistanceKm(driverLat, driverLng, destLat, destLng);
                const hasReached = reachedLocationJobIds.has(activeDeliveryJob.id);

                return (
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between text-xs bg-black/40 p-3 rounded-2xl border border-white/5">
                      <span className="text-gray-400">Remaining Distance:</span>
                      <span className="font-mono font-extrabold text-gold-400">
                        {distanceKm.toFixed(1)} km away
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {!hasReached ? (
                        <button
                          onClick={() => handleMarkReachedLocation(activeDeliveryJob)}
                          className="w-full bg-gold-500 hover:bg-gold-400 text-black font-extrabold py-3.5 px-4 rounded-2xl uppercase tracking-wider text-xs flex items-center justify-center gap-2 shadow-lg shadow-gold-500/20 active:scale-95 transition-all"
                        >
                          <MapPin size={16} />
                          <span>I Have Reached Location</span>
                        </button>
                      ) : (
                        <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
                          <CheckCircle2 size={16} className="text-emerald-400" />
                          <span>Location Reached</span>
                        </div>
                      )}

                      <a
                        href={`https://www.google.com/maps/dir/?api=1&destination=${destLat},${destLng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full bg-white/10 hover:bg-white/20 text-white font-bold py-3.5 px-4 rounded-2xl uppercase tracking-wider text-xs flex items-center justify-center gap-2 transition-all text-center border border-white/10"
                      >
                        <Navigation size={14} className="text-gold-400" />
                        <span>Navigate in Maps</span>
                      </a>
                    </div>

                    <button
                      onClick={() => handleOpenOtpModal(activeDeliveryJob)}
                      className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-black py-4 px-6 rounded-2xl uppercase tracking-widest text-xs flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20 active:scale-95 transition-all"
                    >
                      <KeyRound size={16} />
                      <span>Payment on Delivery & Complete</span>
                    </button>
                  </div>
                );
              })()}
            </div>
          </div>
        ) : !isDriverOnline ? (
          /* Driver Offline State */
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 mx-auto flex items-center justify-center text-gray-500">
              <Power size={24} />
            </div>
            <h3 className="font-bold text-white text-base">You are currently Offline</h3>
            <p className="text-xs text-gray-400 max-w-xs mx-auto">
              Switch to Online mode at the top to receive incoming vehicle transport dispatches.
            </p>
          </div>
        ) : availableJobs.length > 0 ? (
          /* Available Jobs Feed */
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-gold-400">
                Available Dispatches ({availableJobs.length})
              </span>
              <button
                onClick={() => {
                  fetchPendingOrdersFromSupabase().then((jobs) => setAvailableJobs(jobs));
                }}
                className="text-[11px] text-gray-400 hover:text-white flex items-center gap-1"
              >
                <RefreshCw size={12} />
                <span>Refresh</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {availableJobs.map((job) => (
                <div
                  key={job.id}
                  className="bg-neutral-900 border border-white/10 hover:border-gold-500/40 rounded-2xl p-4 flex items-center justify-between gap-3 transition-colors"
                >
                  <div className="min-w-0">
                    <span className="text-[9px] font-bold uppercase px-2 py-0.5 rounded bg-purple-900/40 text-purple-300 border border-purple-500/30">
                      {job.service_type || 'TRANSPORT'}
                    </span>
                    <h4 className="font-bold text-sm text-white mt-1 truncate">
                      {job.fuelType || job.fuel_type || 'Vehicle Transport'}
                    </h4>
                    <p className="text-xs text-gray-400 truncate mt-0.5">
                      {job.location?.address || 'Hyderabad Operational Area'}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-base font-black text-emerald-400 font-mono">
                      {currencySymbol}{job.price || 450}
                    </div>
                    <button
                      onClick={() => handleAcceptJob(job.id)}
                      className="mt-1 bg-gold-500 hover:bg-gold-400 text-black font-extrabold text-[11px] px-3.5 py-1.5 rounded-xl uppercase tracking-wider transition-all active:scale-95 shadow-md shadow-gold-500/10"
                    >
                      Accept
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* Waiting for jobs radar */
          <div className="py-10 text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-gold-500/10 border border-gold-500/20 mx-auto flex items-center justify-center relative">
              <div className="absolute inset-0 rounded-full border border-gold-500/30 animate-ping" />
              <Radio size={24} className="text-gold-400" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Waiting for jobs</h3>
              <p className="text-xs text-gray-400 max-w-xs mx-auto mt-1">
                Your status is Online. New transport dispatches will ring here automatically.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Incoming Job Dialog with Ringtone */}
      <IncomingJobDialog 
        order={activeIncomingJob}
        onAccept={handleAcceptJob}
        onDecline={handleDeclineIncomingJob}
        currencySymbol={currencySymbol}
        timeoutSeconds={30}
      />

      {/* Handover OTP and Payment Verification Modal */}
      <OtpVerificationModal 
        isOpen={showOtpModal}
        order={orderForOtp}
        driverId={profile.uid || 'HYD-NALLAGANDLA-01'}
        hasReachedLocation={Boolean(orderForOtp && reachedLocationJobIds.has(orderForOtp.id))}
        onClose={() => {
          setShowOtpModal(false);
          setOrderForOtp(null);
        }}
        onVerifyAndComplete={handleVerifyAndCompleteOtp}
        currencySymbol={currencySymbol}
      />
    </div>
  );
}
