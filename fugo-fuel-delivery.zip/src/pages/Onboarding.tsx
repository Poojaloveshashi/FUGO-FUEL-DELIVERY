import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowRight, 
  Wrench,
  User,
  Phone,
  Loader2,
  CheckCircle2
} from 'lucide-react';
import { UserRole, UserStatus } from '../types';
import { createProfile } from '../services/store';
import { supabase } from '../supabase';

interface OnboardingProps {
  user: any;
  onComplete: () => void;
}

export default function Onboarding({ user, onComplete }: OnboardingProps) {
  const [fullName, setFullName] = useState(user?.displayName || '');
  const [phoneNumber, setPhoneNumber] = useState(user?.phoneNumber || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleComplete = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!fullName.trim()) {
      setError('Please enter your full name');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // 1. Update Supabase Auth User metadata
      const { error: authError } = await supabase.auth.updateUser({
        data: {
          full_name: fullName.trim(),
          phone: phoneNumber.trim(),
        },
      });

      if (authError) {
        console.warn('Update user metadata warning:', authError.message);
      }

      // 2. Create / persist driver profile
      await createProfile({
        uid: user.uid,
        displayName: fullName.trim(),
        role: UserRole.DRIVER,
        status: UserStatus.ONLINE,
        phone: phoneNumber.trim(),
        email: user.email || '',
        location: {
          lat: 17.4435,
          lng: 78.3582,
          address: 'Hyderabad Operational Hub',
        },
      });

      onComplete();
    } catch (err: any) {
      console.error('Onboarding completion error:', err);
      setError(err?.message || 'Failed to initialize profile. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-[-20%] left-[10%] w-[60%] h-[60%] bg-gold-500/10 blur-[150px] rounded-full animate-pulse" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md z-10"
      >
        <div className="bg-gray-900/70 border border-white/10 backdrop-blur-3xl p-8 rounded-[36px] shadow-2xl relative">
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-gold-500 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-gold-500/20 mb-3">
                <Wrench size={30} className="text-black" />
              </div>
              <h2 className="text-white font-display font-bold text-2xl uppercase tracking-tight italic">
                Driver Profile Setup
              </h2>
              <p className="text-gray-400 text-xs">
                Set up your driver partner identity for customer dispatches.
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-300 text-xs font-medium">
                {error}
              </div>
            )}

            <form onSubmit={handleComplete} className="space-y-4">
              <div>
                <label className="text-gray-400 text-[10px] uppercase font-bold tracking-widest block mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input 
                    type="text"
                    placeholder="e.g. Ramesh Kumar"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-2xl py-3.5 pl-11 pr-4 text-white focus:outline-none focus:border-gold-500 transition-all font-medium text-sm"
                    required
                    autoFocus
                  />
                </div>
              </div>

              <div>
                <label className="text-gray-400 text-[10px] uppercase font-bold tracking-widest block mb-2">
                  Contact Mobile Number
                </label>
                <div className="relative">
                  <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input 
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-2xl py-3.5 pl-11 pr-4 text-white focus:outline-none focus:border-gold-500 transition-all font-medium text-sm"
                  />
                </div>
              </div>

              <button 
                type="submit"
                disabled={loading || !fullName.trim()}
                className="w-full bg-gold-500 hover:bg-gold-400 disabled:opacity-40 text-black font-extrabold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all uppercase tracking-wider text-xs shadow-xl shadow-gold-500/20 active:scale-95 mt-4"
              >
                {loading ? (
                  <Loader2 size={16} className="animate-spin text-black" />
                ) : (
                  <>
                    <span>Enter Driver Workspace</span>
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
