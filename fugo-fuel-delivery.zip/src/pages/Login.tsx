import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  ChevronRight, 
  ShieldCheck, 
  ArrowLeft,
  Loader2,
  AlertCircle,
  Wrench,
  CheckCircle2,
  MapPin,
  RefreshCw
} from 'lucide-react';
import { supabase } from '../supabase';

interface LoginProps {
  onSuccess?: () => void;
}

export default function Login({ onSuccess }: LoginProps) {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resendCountdown, setResendCountdown] = useState(0);
  const [resending, setResending] = useState(false);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  // 30-second resend countdown timer
  useEffect(() => {
    if (resendCountdown <= 0) return;
    const interval = setInterval(() => {
      setResendCountdown((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [resendCountdown]);

  // Request Email OTP
  const handleSendOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setError('Please provide a valid email address');
      return;
    }

    setError(null);
    setInfoMessage(null);
    setLoading(true);

    try {
      const { error: authError } = await supabase.auth.signInWithOtp({
        email: cleanEmail,
        options: {
          shouldCreateUser: true,
        },
      });

      if (authError) {
        setError(authError.message || 'Unable to send verification code. Please retry.');
      } else {
        setStep('otp');
        setOtp('');
        setResendCountdown(30);
        setInfoMessage(`We sent a 6-digit access code to ${cleanEmail}`);
      }
    } catch (err: any) {
      setError(err?.message || 'Authentication service unreachable. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  // Verify OTP
  const handleVerifyOtp = async (codeToVerify?: string) => {
    const code = (codeToVerify || otp).trim();
    if (code.length < 6) {
      setError('Please enter the complete 6-digit verification code');
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    setError(null);
    setLoading(true);

    try {
      const { data, error: verifyError } = await supabase.auth.verifyOtp({
        email: cleanEmail,
        token: code,
        type: 'email',
      });

      if (verifyError) {
        setError(verifyError.message || 'Invalid or expired code. Please check and retry.');
      } else if (data?.session) {
        if (onSuccess) onSuccess();
      } else {
        setError('Verification failed. Please request a new code.');
      }
    } catch (err: any) {
      setError(err?.message || 'Verification failed. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  // Resend code
  const handleResend = async () => {
    if (resendCountdown > 0 || resending) return;
    setResending(true);
    setError(null);
    const cleanEmail = email.trim().toLowerCase();

    try {
      const { error: authError } = await supabase.auth.signInWithOtp({
        email: cleanEmail,
        options: {
          shouldCreateUser: true,
        },
      });

      if (authError) {
        setError(authError.message || 'Failed to resend code');
      } else {
        setResendCountdown(30);
        setInfoMessage(`A fresh verification code was sent to ${cleanEmail}`);
      }
    } catch (err: any) {
      setError(err?.message || 'Error resending code');
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden font-sans">
      {/* Ambience Background */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-gold-600/15 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-gold-900/10 blur-[100px] rounded-full" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md z-10"
      >
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-tr from-gold-600 to-gold-400 rounded-2xl mx-auto mb-3 flex items-center justify-center shadow-[0_15px_35px_rgba(247,167,10,0.35)] rotate-2">
            <Wrench size={32} className="text-black -rotate-2" />
          </div>
          <h1 className="text-white font-display font-bold text-3xl italic tracking-tight uppercase">
            FUGO FULFILLMENT
          </h1>
          <div className="flex items-center justify-center gap-1.5 mt-1.5">
            <MapPin size={12} className="text-gold-400" />
            <p className="text-gold-400 text-[10px] font-bold uppercase tracking-widest">
              Driver & Transport Network • Hyderabad
            </p>
          </div>
        </div>

        {/* Main Card */}
        <div className="bg-gray-950/85 border border-white/10 backdrop-blur-2xl p-6 sm:p-8 rounded-[32px] shadow-2xl relative">
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-3.5 mb-5 bg-red-500/10 border border-red-500/30 rounded-xl text-red-300 text-xs font-medium"
            >
              <AlertCircle size={15} className="shrink-0 text-red-400" />
              <span>{error}</span>
            </motion.div>
          )}

          {infoMessage && (
            <motion.div 
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-3.5 mb-5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs font-medium"
            >
              <CheckCircle2 size={15} className="shrink-0 text-emerald-400" />
              <span>{infoMessage}</span>
            </motion.div>
          )}

          <AnimatePresence mode="wait">
            {step === 'email' ? (
              <motion.div
                key="step-email"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-5"
              >
                <div>
                  <h2 className="text-white font-bold text-lg mb-1 flex items-center gap-2">
                    <Mail size={18} className="text-gold-400" />
                    <span>Driver Partner Sign In</span>
                  </h2>
                  <p className="text-gray-400 text-xs">
                    Enter your email to receive a secure one-time access code.
                  </p>
                </div>

                <form onSubmit={handleSendOtp} className="space-y-4">
                  <div>
                    <label className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-2">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                      <input 
                        type="email"
                        placeholder="driver@fugo.in"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (error) setError(null);
                        }}
                        className="w-full bg-black/60 border border-white/10 rounded-2xl py-3.5 pl-11 pr-4 text-white focus:outline-none focus:border-gold-500 transition-all font-mono text-sm"
                        required
                        autoFocus
                      />
                    </div>
                  </div>

                  <button 
                    type="submit"
                    disabled={loading || !email.includes('@')}
                    className="w-full bg-gold-500 hover:bg-gold-400 disabled:opacity-40 text-black font-extrabold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all uppercase tracking-wider text-xs shadow-xl shadow-gold-500/20 active:scale-95"
                  >
                    {loading ? (
                      <Loader2 size={16} className="animate-spin text-black" />
                    ) : (
                      <>
                        <span>Send Login Code</span>
                        <ChevronRight size={16} />
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="step-otp"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="space-y-5"
              >
                <div>
                  <button 
                    type="button"
                    onClick={() => {
                      setStep('email');
                      setError(null);
                    }}
                    className="text-gray-400 hover:text-white transition-colors flex items-center gap-1 text-[11px] font-bold mb-3"
                  >
                    <ArrowLeft size={14} /> Back to email
                  </button>

                  <h2 className="text-white font-bold text-lg mb-1 flex items-center gap-2">
                    <ShieldCheck size={18} className="text-gold-400" />
                    <span>Enter Verification Code</span>
                  </h2>
                  <p className="text-gray-400 text-xs">
                    Sent to <span className="text-gold-400 font-mono font-bold">{email}</span>
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <input 
                      type="text"
                      maxLength={6}
                      inputMode="numeric"
                      placeholder="••••••"
                      value={otp}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, '');
                        setOtp(val);
                        if (error) setError(null);
                        if (val.length === 6) {
                          handleVerifyOtp(val);
                        }
                      }}
                      className="w-full bg-black/60 border border-gold-500/50 rounded-2xl py-4 px-4 text-center text-white focus:outline-none focus:border-gold-400 transition-all font-mono text-3xl tracking-[0.35em] placeholder:text-gray-700"
                      autoFocus
                    />
                  </div>

                  <button 
                    type="button"
                    onClick={() => handleVerifyOtp()}
                    disabled={loading || otp.length !== 6}
                    className="w-full bg-gold-500 hover:bg-gold-400 disabled:opacity-40 text-black font-extrabold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all uppercase tracking-wider text-xs shadow-xl shadow-gold-500/20 active:scale-95"
                  >
                    {loading ? (
                      <Loader2 size={16} className="animate-spin text-black" />
                    ) : (
                      <>
                        <span>Verify & Enter</span>
                        <ChevronRight size={16} />
                      </>
                    )}
                  </button>

                  {/* 30s Countdown / Resend */}
                  <div className="pt-2 flex items-center justify-between text-xs">
                    {resendCountdown > 0 ? (
                      <span className="text-gray-400 text-[11px]">
                        Resend code in <strong className="text-gold-400 font-mono">{resendCountdown}s</strong>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={handleResend}
                        disabled={resending}
                        className="text-gold-400 hover:text-gold-300 font-bold text-[11px] flex items-center gap-1.5 transition-colors"
                      >
                        <RefreshCw size={12} className={resending ? 'animate-spin' : ''} />
                        <span>Resend verification code</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setStep('email');
                        setError(null);
                      }}
                      className="text-gray-400 hover:text-white text-[11px] underline"
                    >
                      Change email
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="mt-6 text-center space-y-1">
          <p className="text-gray-500 text-[10px] font-medium tracking-wide">
            HYDERABAD OPERATIONAL CLUSTER
          </p>
          <p className="text-gray-600 text-[9px]">
            Vehicle Retrieval & Transport Dispatch Network
          </p>
        </div>
      </motion.div>
    </div>
  );
}
