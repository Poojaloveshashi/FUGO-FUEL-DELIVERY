import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Order } from './types';

// Supabase project constants
export const DEFAULT_SUPABASE_PROJECT_ID = 'arierwpjaksxxnmvbqwn';
export const DEFAULT_SUPABASE_URL = 'https://arierwpjaksxxnmvbqwn.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable__c-Q3k0ibuQMt3_mtYpRNw_Se-8kFbS';

export const HARDCODED_SUPABASE_URL = DEFAULT_SUPABASE_URL;
export const HARDCODED_SUPABASE_KEY = DEFAULT_SUPABASE_ANON_KEY;

export function isValidSupabaseUrl(url?: string): boolean {
  if (!url) return false;
  const clean = String(url).trim();
  if (!clean.startsWith('https://')) return false;
  if (clean.includes('your-project-id')) return false;
  if (clean === 'https://your-project-id.supabase.co' || clean === 'YOUR_SUPABASE_URL' || clean === 'MY_APP_URL') {
    return false;
  }
  return true;
}

export function isValidSupabaseKey(key?: string): boolean {
  if (!key) return false;
  const clean = String(key).trim();
  if (clean.toLowerCase() === 'ap-southeast-1') return false;
  if (clean === 'YOUR_ACTUAL_ANON_KEY' || clean === 'YOUR_SUPABASE_ANON_KEY') return false;
  return (
    clean.startsWith('sb_publishable_') ||
    clean.startsWith('sb_secret_') ||
    clean.startsWith('sb_') ||
    clean.startsWith('eyJ')
  );
}

function resolveSupabaseUrl(rawUrl?: string): string {
  if (rawUrl && isValidSupabaseUrl(rawUrl)) {
    return String(rawUrl).trim().replace(/\/+$/, '');
  }
  if (typeof localStorage !== 'undefined') {
    try {
      const stored = localStorage.getItem('fugo_supabase_url');
      if (stored) {
        if (isValidSupabaseUrl(stored)) {
          return stored.trim().replace(/\/+$/, '');
        } else {
          localStorage.removeItem('fugo_supabase_url');
        }
      }
    } catch {
      // ignore
    }
  }
  return DEFAULT_SUPABASE_URL;
}

function resolveSupabaseAnonKey(rawKey?: string): string {
  if (rawKey && isValidSupabaseKey(rawKey)) {
    return String(rawKey).trim();
  }
  if (typeof localStorage !== 'undefined') {
    try {
      const stored = localStorage.getItem('fugo_supabase_anon_key');
      if (stored) {
        if (stored === 'sb_secret_1P7d_dTOUdmN68jBl27Ing_RCl-Q8PT') {
          localStorage.setItem('fugo_supabase_anon_key', DEFAULT_SUPABASE_ANON_KEY);
          return DEFAULT_SUPABASE_ANON_KEY;
        }
        if (isValidSupabaseKey(stored)) {
          return stored.trim();
        } else {
          localStorage.removeItem('fugo_supabase_anon_key');
        }
      }
    } catch {
      // ignore
    }
  }
  return DEFAULT_SUPABASE_ANON_KEY;
}

const envProvidedUrl = typeof import.meta !== 'undefined' ? (import.meta as any).env?.VITE_SUPABASE_URL : undefined;
const envProvidedKey = typeof import.meta !== 'undefined' ? (import.meta as any).env?.VITE_SUPABASE_ANON_KEY : undefined;

export const supabaseUrl = resolveSupabaseUrl(envProvidedUrl);
export const supabaseAnonKey = resolveSupabaseAnonKey(envProvidedKey);

export const SUPABASE_URL = supabaseUrl;
export const SUPABASE_ANON_KEY = supabaseAnonKey;
export const SUPABASE_PROJECT_ID = DEFAULT_SUPABASE_PROJECT_ID;

/**
 * Cleanly initialized Supabase client
 */
export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Supabase instance object pattern compatible with Flutter / Dart API syntax:
 * Supabase.instance.client.from('orders')...
 */
export const Supabase = {
  get instance() {
    return {
      client: supabase,
    };
  },
  client: supabase,
};

/**
 * Defensive acceptOrder / acceptJob:
 * When driver taps 'ACCEPT':
 * - Updates ONLY essential fields:
 *   {
 *     status: 'DISPATCHED',
 *     assigned_partner_id: 'HYD-NALLAGANDLA-01',
 *     accepted_at: new Date().toISOString()
 *   }
 * - Wrapped in try/catch block.
 * - If error is returned: alert(error.message) and console.error('Full error:', error).
 * - Avoids updating unverified foreign keys or non-existent columns.
 */
export async function acceptJob(
  orderId: string, 
  _driverId?: string,
  _partnerType?: string
): Promise<{ success: boolean; error?: string; alreadyTaken?: boolean; order?: Order }> {
  try {
    const acceptedAt = new Date().toISOString();
    const { data, error } = await supabase
      .from('orders')
      .update({
        status: 'DISPATCHED',
        assigned_partner_id: 'HYD-NALLAGANDLA-01',
        accepted_at: acceptedAt
      })
      .eq('id', orderId)
      .select();

    if (error) {
      console.error('Full error:', error);
      return { success: false, error: error.message };
    }

    if (!data || data.length === 0) {
      return { success: false, alreadyTaken: true, error: 'Job already taken' };
    }

    return { success: true, order: data[0] as any };
  } catch (err: any) {
    console.error('Full error:', err);
    const msg = err?.message || 'Error updating job';
    return { success: false, error: msg };
  }
}

export const acceptOrder = acceptJob;
export const handleAccept = acceptJob;

/**
 * sendLocationPing: Updates driver coordinates on order row
 * void sendLocationPing(String orderId, double lat, double lng)
 */
export async function sendLocationPing(orderId: string, lat: number, lng: number): Promise<void> {
  const { error } = await supabase
    .from('orders')
    .update({
      driver_lat: lat,
      driver_lng: lng,
    })
    .eq('id', orderId);

  if (error) {
    console.warn('[Supabase] sendLocationPing notice:', error.message);
  }
}

/**
 * Whenever handleOrderSubmit is called, it inserts into public.orders
 * and if an error occurs, it displays/returns the actual error.message instead of generic text.
 */
export async function handleOrderSubmit(orderPayload?: any): Promise<{ success: boolean; data?: any; error?: string }> {
  const generatedId = orderPayload?.id || `ord_supa_${Date.now()}`;
  const generatedOtp = String(Math.floor(1000 + Math.random() * 9000));

  const payload: any = {
    id: generatedId,
    customer_id: orderPayload?.customerId || orderPayload?.customer_id || 'cust_gachibowli',
    status: 'PENDING',
    service_type: orderPayload?.service_type || orderPayload?.serviceType || 'FUEL',
    fuel_type: orderPayload?.fuel_type || orderPayload?.fuelType || 'High Speed Diesel (30L)',
    amount: orderPayload?.amount || orderPayload?.liters || 30,
    liters: orderPayload?.amount || orderPayload?.liters || 30,
    price: orderPayload?.price || 2850,
    address: orderPayload?.location?.address || orderPayload?.address || 'Gachibowli Circle, Hyderabad',
    lat: orderPayload?.location?.lat ?? orderPayload?.lat ?? 17.4435,
    lng: orderPayload?.location?.lng ?? orderPayload?.lng ?? 78.3582,
    otp: generatedOtp,
    handshake_otp: generatedOtp,
    delivery_otp: generatedOtp,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    ...(orderPayload && typeof orderPayload === 'object' ? orderPayload : {}),
  };

  try {
    const { data, error } = await supabase
      .from('orders')
      .insert([payload])
      .select()
      .single();

    if (error) {
      console.warn('[Supabase] handleOrderSubmit error:', error.message);
      return { success: false, error: error.message };
    }
    return { success: true, data };
  } catch (err: any) {
    const errorMsg = err?.message || String(err);
    console.warn('[Supabase] handleOrderSubmit exception:', errorMsg);
    return { success: false, error: errorMsg };
  }
}

export {
  validateSupabaseAnonKey,
  isDeliveryOrder,
  isEligibleServiceType,
  normalizeSupabaseOrder,
  insertSupabaseOrder,
  fetchPendingOrdersFromSupabase,
  subscribeToSupabasePendingOrders,
  acceptSupabaseOrderToInTransit,
  completeSupabaseOrderWithOtp,
  subscribeToOrderRealtime,
  placeOrderWithRealtimeSubscription,
} from './lib/supabase';

export default supabase;
