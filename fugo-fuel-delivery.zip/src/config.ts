/**
 * Global application feature configuration
 */
export const FUEL_SALES_ENABLED = false;
