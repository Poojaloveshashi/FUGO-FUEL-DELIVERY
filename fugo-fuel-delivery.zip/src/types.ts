export enum UserRole {
  CUSTOMER = 'customer',
  DRIVER = 'driver',
  SUPPORT = 'support',
}

export enum UserStatus {
  ONLINE = 'online',
  OFFLINE = 'offline',
}

export enum OrderStatus {
  PENDING = 'PENDING',
  DISPATCHED = 'DISPATCHED',
  ASSIGNED = 'ASSIGNED',
  ACCEPTED = 'ACCEPTED',
  IN_TRANSIT = 'IN_TRANSIT',
  DELIVERING = 'DELIVERING',
  DELIVERED = 'DELIVERED',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
}

export type WorkerSpecialty = 'BOWSER_DRIVER' | 'MECHANIC';

export interface Location {
  lat: number;
  lng: number;
  address?: string;
}

export interface UserProfile {
  uid: string;
  email?: string;
  displayName?: string;
  role: UserRole;
  workerSpecialty?: WorkerSpecialty;
  status: UserStatus;
  location?: Location;
  lastActive?: any;
  phone?: string;
}

export interface Order {
  id: string;
  customerId?: string;
  customer_id?: string;
  driverId?: string;
  driver_id?: string;
  assigned_partner_id?: string;
  assignedPartnerId?: string;
  assigned_partner_type?: string;
  assignedPartnerType?: string;
  accepted_at?: string;
  acceptedAt?: string;
  driver_lat?: number;
  driver_lng?: number;
  driverLocation?: { lat: number; lng: number };
  status: OrderStatus | string;
  service_type?: 'FUEL' | 'TRANSPORT' | 'MAINTENANCE' | 'PARTS' | 'REPAIR' | string;
  serviceType?: 'FUEL' | 'TRANSPORT' | 'MAINTENANCE' | 'PARTS' | 'REPAIR' | string;
  job_kind?: 'VEHICLE_PICKUP' | 'VEHICLE_RETURN' | string;
  jobKind?: 'VEHICLE_PICKUP' | 'VEHICLE_RETURN' | string;
  description?: string;
  fuelType?: string;
  fuel_type?: string;
  amount?: number;
  liters?: number;
  litres?: number;
  location: Location;
  price: number;
  otp?: string;
  delivery_otp?: string;
  handshake_otp?: string;
  completed_at?: string;
  source_app?: string;
  sourceAppUrl?: string;
  customer_name?: string;
  customerName?: string;
  customer_phone?: string;
  customerPhone?: string;
  total_amount?: number;
  totalAmount?: number;
  payment_method?: string;
  paymentMethod?: string;
  payment_status?: string;
  paymentStatus?: string;
  driver_payout?: number;
  driverPayout?: number;
  driver_speed_kmh?: number;
  delivery_fee?: number;
  gst_amount?: number;
  paid_at?: string;
  collected_by?: string;
  verified_otp?: string;
  createdAt?: any;
  created_at?: any;
  updatedAt?: any;
  updated_at?: any;
}

export interface SOSAlert {
  id: string;
  userId: string;
  location: Location;
  status: 'active' | 'resolved';
  createdAt: any;
}

export type FulfilmentCategory = 'DELIVERY' | 'MECHANICS' | 'OUTLETS' | 'WAREHOUSE' | 'ALL';
export type ClientAppType = 'FUEL_APP' | 'REPAIRS_APP' | 'SERVICE_APP';

export interface WarehouseStockItem {
  id: string;
  name: string;
  category: 'fuel' | 'parts';
  quantity: number;
  unit: string;
  minThreshold: number;
}

export interface OfflineOutlet {
  id: string;
  name: string;
  type: 'pump' | 'garage' | 'hub';
  address: string;
  lat: number;
  lng: number;
  isOpen: boolean;
  fuelAvailable: boolean;
}
