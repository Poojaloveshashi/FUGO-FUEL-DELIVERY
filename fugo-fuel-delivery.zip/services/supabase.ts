import { createClient, SupabaseClient } from '@supabase/supabase-js';

export const DEFAULT_SUPABASE_PROJECT_ID = 'arierwpjaksxxnmvbqwn';
export const DEFAULT_SUPABASE_URL = 'https://arierwpjaksxxnmvbqwn.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable__c-Q3k0ibuQMt3_mtYpRNw_Se-8kFbS';

export const HARDCODED_SUPABASE_URL = DEFAULT_SUPABASE_URL;
export const HARDCODED_SUPABASE_KEY = DEFAULT_SUPABASE_ANON_KEY;

export function isValidSupabaseUrl(url?: string): boolean {
  if (!url) return false;
  const clean = String(url).trim();
  if (!clean.startsWith('https://')) return false;
  if (clean.includes('your-project-id')) return false;
  if (clean === 'https://your-project-id.supabase.co' || clean === 'YOUR_SUPABASE_URL' || clean === 'MY_APP_URL') {
    return false;
  }
  return true;
}

export function isValidSupabaseKey(key?: string): boolean {
  if (!key) return false;
  const clean = String(key).trim();
  if (clean.toLowerCase() === 'ap-southeast-1') return false;
  if (clean === 'YOUR_ACTUAL_ANON_KEY' || clean === 'YOUR_SUPABASE_ANON_KEY') return false;
  return (
    clean.startsWith('sb_publishable_') ||
    clean.startsWith('sb_secret_') ||
    clean.startsWith('sb_') ||
    clean.startsWith('eyJ')
  );
}

const envUrl = (
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_URL) ||
  ''
).trim();

const envKey = (
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_SUPABASE_ANON_KEY) ||
  ''
).trim();

export const supabaseUrl = isValidSupabaseUrl(envUrl) ? envUrl : DEFAULT_SUPABASE_URL;
export const supabaseAnonKey = isValidSupabaseKey(envKey) ? envKey : DEFAULT_SUPABASE_ANON_KEY;

export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseAnonKey);

export default supabase;
